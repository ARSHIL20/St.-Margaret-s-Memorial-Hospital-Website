/* =================================================================
   corruption.js — CORRUPTION ENGINE
   -----------------------------------------------------------------
   Single source of truth for the site's "haunt state".
   Global `CorruptionState` object; every other module reads/writes
   through it via the event emitter pattern.

   HOW TO EXTEND (for hackathon judges / future devs):
   ---------------------------------------------------
   1. To add a NEW CORRUPTION LEVEL EFFECT:
      - Subscribe to `corruption:changed` and check `state.level`.
      - See main.js for examples.
      - Thresholds: see `THRESHOLDS` below — edit to tune difficulty.

   2. To add a NEW STAT (e.g., hovers over a specific button):
      - Add to `CorruptionState.stats` defaults.
      - Add a mutator method like `recordHover(el)`.
      - Emit `corruption:stats` so UI can react.

   3. To add a NEW TRIGGER (e.g., keystroke, paste, scroll depth):
      - Call `CorruptionState.recordClick()` or a new `recordX()` method.
      - `recordInteraction(weight)` is the generic weight adder.

   THRESHOLDS: each level's cumulative click cost (approximate).
   Fast clicks give BONUS corruption (velocity factor).
   ================================================================= */

(function () {
  'use strict';

  /* ---------- THRESHOLDS (tune these) ----------
     Level 0 → 1 : 3 clicks
     Level 1 → 2 : 8 clicks
     Level 2 → 3 : 15 clicks
     ... up to Level 10.
  ---------------------------------------------- */
  const THRESHOLDS = [0, 3, 8, 15, 25, 38, 54, 72, 94, 120, 150];
  const MAX_LEVEL = 10;

  /* Velocity: clicks in last 2s over this count give +bonus corruption per click. */
  const VELOCITY_WINDOW_MS = 2000;
  const VELOCITY_BONUS_THRESHOLD = 4; // more than 4 clicks in 2s = panic clicks

  /* Idle time (ms) after which corruption "bleeds off" slightly (sanity regen). */
  const IDLE_REGEN_MS = 12000;
  const IDLE_REGEN_RATE = 0.4; // per 12s idle — small sanity recovery

  const state = {
    /* ---------- CORE ---------- */
    level: 0,                // 0 – 10
    corruption: 0,           // raw score before bucketing into level
    totalClicks: 0,

    /* ---------- BEHAVIORAL STATS ---------- */
    pagesVisited: new Set(),
    pagesAvoided: new Set(['ward13', 'contact']), // initial suspicion
    lastClickTime: 0,
    recentClicks: [],        // timestamps inside VELOCITY_WINDOW_MS
    siteEntryTime: Date.now(),
    lastInteractionTime: Date.now(),
    hoverTargets: new Map(), // element id → count
    idleSince: null,
    clickSpeedRecent: [],    // inter-click deltas

    /* ---------- TOGGLES ---------- */
    nightShift: false,
    audioMuted: false,
    volume: 0.6,
    daredevil: false,
    audioUnlocked: false,

    /* ---------- PAGE CLOCK ---------- */
    footerMinutes: 47,       // starts 11:47 PM
    footerHour: 11,

    /* ---------- ONE-SHOT FLAGS ---------- */
    flags: {
      ward13Revealed: false,
      receptionistGreeted: false,
      receptionistVelocityComment: false,
      nightRoundsShown: false,
      nurseStationShown: false,
      finalePlayed: false,
      mirrorAdded: false,
      daredevilTriggered: false,
      appointmentSubmitted: false,
    },
  };

  /* ---------- EVENT EMITTER ---------- */
  const listeners = new Map();
  function on(event, cb) {
    if (!listeners.has(event)) listeners.set(event, new Set());
    listeners.get(event).add(cb);
  }
  function off(event, cb) {
    listeners.get(event)?.delete(cb);
  }
  function emit(event, payload) {
    listeners.get(event)?.forEach(fn => {
      try { fn(payload, state); } catch (e) { console.error('[corruption] listener error', e); }
    });
  }

  /* ---------- INTERNAL HELPERS ---------- */
  function updateLevel() {
    const prevLevel = state.level;
    let lvl = 0;
    for (let i = THRESHOLDS.length - 1; i >= 0; i--) {
      if (state.corruption >= THRESHOLDS[i]) { lvl = i; break; }
    }
    lvl = Math.min(MAX_LEVEL, lvl);
    if (lvl !== prevLevel) {
      state.level = lvl;
      emit('corruption:level', { oldLevel: prevLevel, newLevel: lvl });
      emit('corruption:changed', state);
    }
    return lvl;
  }

  function velocityBonus() {
    const now = Date.now();
    state.recentClicks = state.recentClicks.filter(t => now - t <= VELOCITY_WINDOW_MS);
    if (state.recentClicks.length > VELOCITY_BONUS_THRESHOLD) {
      // 1 bonus per extra panic-click (capped so one burst can't instantly max)
      return Math.min(3, state.recentClicks.length - VELOCITY_BONUS_THRESHOLD);
    }
    return 0;
  }

  /* ---------- PUBLIC MUTATORS ---------- */
  function recordClick(el) {
    state.totalClicks++;
    state.lastInteractionTime = Date.now();
    state.idleSince = null;

    const now = Date.now();
    if (state.lastClickTime) state.clickSpeedRecent.push(now - state.lastClickTime);
    if (state.clickSpeedRecent.length > 10) state.clickSpeedRecent.shift();
    state.lastClickTime = now;
    state.recentClicks.push(now);

    let weight = 1 + velocityBonus();

    // Navigation clicks count slightly more (exploration = commitment).
    if (el && el.closest && (el.closest('[data-nav]') || el.closest('nav'))) {
      weight += 0.5;
    }
    // Form clicks count more (engaging deeply).
    if (el && el.closest && el.closest('form')) weight += 0.3;
    // Gallery clicks (curiosity, near the ward13 door).
    if (el && el.closest && el.closest('#gallery-grid')) weight += 0.6;

    state.corruption += weight;
    updateLevel();
    emit('corruption:click', { element: el, weight });
    emit('corruption:changed', state);
    return state.level;
  }

  function recordHover(el, id) {
    if (!id) return;
    const n = (state.hoverTargets.get(id) || 0) + 1;
    state.hoverTargets.set(id, n);
    if (n % 5 === 0) {
      emit('cor:hover-hotspot', { id, count: n });
    }
  }

  function recordPage(pageId) {
    state.pagesVisited.add(pageId);
    state.pagesAvoided.delete(pageId);
    // footer clock advances 1 minute per page visit
    state.footerMinutes++;
    if (state.footerMinutes >= 60) {
      state.footerMinutes = 0;
      state.footerHour++;
      if (state.footerHour > 12) state.footerHour = 1;
    }
    state.lastInteractionTime = Date.now();
    emit('corruption:page', pageId);
    emit('corruption:changed', state);
  }

  function recordInteraction(weight = 1) {
    state.corruption += weight;
    state.lastInteractionTime = Date.now();
    state.idleSince = null;
    updateLevel();
    emit('corruption:changed', state);
  }

  function reset() {
    state.level = 0;
    state.corruption = 0;
    state.totalClicks = 0;
    state.pagesVisited.clear();
    state.pagesAvoided = new Set(['ward13', 'contact']);
    state.recentClicks.length = 0;
    state.clickSpeedRecent.length = 0;
    state.siteEntryTime = Date.now();
    state.lastInteractionTime = Date.now();
    state.hoverTargets.clear();
    state.footerMinutes = 47;
    state.footerHour = 11;
    state.idleSince = null;
    Object.keys(state.flags).forEach(k => state.flags[k] = false);
    emit('corruption:reset');
    emit('corruption:level', { oldLevel: 99, newLevel: 0 });
    emit('corruption:changed', state);
  }

  function getAvgClickSpeed() {
    if (!state.clickSpeedRecent.length) return Infinity;
    return state.clickSpeedRecent.reduce((a,b)=>a+b,0) / state.clickSpeedRecent.length;
  }

  function getTimeOnSite() {
    return (Date.now() - state.siteEntryTime) / 1000;
  }

  /* ---------- IDLE TICK ---------- */
  function idleTick() {
    const now = Date.now();
    if (now - state.lastInteractionTime > IDLE_REGEN_MS) {
      // Slow sanity regen, but never below level threshold (prevents level drop visually jarring).
      const currentFloor = THRESHOLDS[state.level];
      state.corruption = Math.max(currentFloor, state.corruption - IDLE_REGEN_RATE);
      if (!state.idleSince) {
        state.idleSince = now;
        emit('corruption:idle-start', state);
      } else {
        emit('corruption:idle-tick', state);
      }
    }
  }
  setInterval(idleTick, 3000);

  /* ---------- DEBUG API (QA / browser console) ---------- */
  function setLevel(targetLevel) {
    targetLevel = Math.max(0, Math.min(MAX_LEVEL, parseInt(targetLevel, 10) || 0));
    const oldLevel = state.level;
    // Clamp corruption to the floor of the requested level so level reads exactly targetLevel.
    const targetThreshold = THRESHOLDS[targetLevel] || 0;
    if (targetLevel === MAX_LEVEL) {
      state.corruption = THRESHOLDS[MAX_LEVEL] + 1;
    } else {
      state.corruption = targetThreshold;
    }
    state.level = targetLevel;
    emit('corruption:level', { oldLevel, newLevel: targetLevel });
    emit('corruption:changed', state);
    return state.level;
  }
  function nudge(amount) {
    state.corruption = Math.max(0, (state.corruption || 0) + (parseFloat(amount) || 0));
    updateLevel();
    return state.level;
  }
  function getLevel() { return state.level; }

  /* ---------- EXPORT ---------- */
  window.CorruptionState = {
    get level() { return state.level; },
    get raw() { return Object.freeze({ ...state }); },
    get s() { return state; },           // mutable read access for modules that know what they're doing
    stats: state,                         // legacy alias
    thresholds: Object.freeze([...THRESHOLDS]),
    maxLevel: MAX_LEVEL,
    velocityBonusWindow: VELOCITY_WINDOW_MS,

    on, off, emit,
    recordClick, recordHover, recordPage, recordInteraction, reset,
    getAvgClickSpeed, getTimeOnSite,
    updateLevel, setLevel, nudge, getLevel,
  };
  /* Legacy QA alias documented in session notes */
  window.ChaosClick = window.CorruptionState;
})();
