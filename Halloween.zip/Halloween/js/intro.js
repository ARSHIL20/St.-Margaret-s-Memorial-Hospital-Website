/* =================================================================
   intro.js — SPLASH SCREEN CONTROLLER
   -----------------------------------------------------------------
   Flow:
     1. Builds the ElectricLogo canvas on the .intro-logo container.
     2. Attempts to play assets/audio/intro.mp3 on begin (user can drop
        "The Nun" ringtone there, renamed).
     3. If the file fails to load, synthesizes a creepy "nunnery" style
        intro drone (low sub rumble + gothic chord swells + eerie air)
        via Web Audio API as a zero-dependency fallback.
     4. On "Click to Begin": plays music, ramps up the electric logo
        intensity for ~3.6s, then bursts + fades splash → reveals site.
     5. Unlocks the main AudioManager so the rest of the site audio
        starts in the unlocked (already user-gestured) state.
   ================================================================= */
(function () {
  'use strict';

  const INTRO_DURATION_MS = 3600;  // How long the intro sequence runs
  const FADE_OUT_MS     = 1100;    // Overlap with splash fade-out CSS
  const INTRO_AUDIO_URL = 'assets/audio/intro.mp3';

  const STATE = {
    logo: null,
    audioEl: null,
    ctx: null,
    fallbackNodes: null,
    masterGain: null,
    started: false,
    ended: false,
  };

  /* ==========================================================
     1. CANVAS ELECTRIC LOGO
     ========================================================== */
  function mountLogo() {
    const c = document.querySelector('.intro-logo');
    if (!c || !window.ElectricLogo) return;
    try {
      STATE.logo = new window.ElectricLogo(c, {
        color: '#d18cf5',
        glowColor: '#ad6dff',
        scale: 0.7,
        intensity: 1.0,
        glow: 1.1,
        thickness: 1.7,
        strands: 4,
        bend: 0.7,
        crackle: 1.7,
        arcs: 1.1,
        flicker: 0.7,
        fill: 0.18,
        speed: 2.7,
        interactive: true,
        cursorIntensity: 0.85,
        cursorRadius: 120,
        theme: 'dark',
      });
    } catch (e) {
      console.warn('[intro] ElectricLogo mount failed', e);
    }
  }

  function logoRampUp() {
    const L = STATE.logo;
    if (!L) return;
    L.setOption('intensity', 1.6);
    L.setOption('glow', 1.6);
    L.setOption('arcs', 2.2);
    L.setOption('flicker', 1.0);
    L.setOption('speed', 4.2);
    // Ramp back down over the intro duration
    const t0 = performance.now();
    const iv = setInterval(() => {
      const t = Math.min(1, (performance.now() - t0) / INTRO_DURATION_MS);
      const e = 1 - t;
      L.setOption('intensity', 1.0 + 0.6 * e);
      L.setOption('glow',      1.1 + 0.5 * e);
      L.setOption('arcs',      1.1 + 1.1 * e);
      L.setOption('flicker',   0.7 + 0.3 * e);
      L.setOption('speed',     2.7 + 1.5 * e);
      if (t >= 1) clearInterval(iv);
    }, 60);
  }

  /* ==========================================================
     2. AUDIO — file-first, synth-fallback
     ========================================================== */
  function ensureCtx() {
    if (STATE.ctx) return STATE.ctx;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      STATE.ctx = new AC();
      STATE.masterGain = STATE.ctx.createGain();
      STATE.masterGain.gain.value = 0;
      STATE.masterGain.connect(STATE.ctx.destination);
    } catch (e) {
      console.warn('[intro] No Web Audio', e);
    }
    return STATE.ctx;
  }

  function setIntroVolume(v) {
    const ctx = STATE.ctx;
    if (ctx && STATE.masterGain) {
      const now = ctx.currentTime;
      STATE.masterGain.gain.cancelScheduledValues(now);
      STATE.masterGain.gain.linearRampToValueAtTime(Math.max(0, Math.min(1, v)), now + 0.05);
    }
    if (STATE.audioEl) {
      try { STATE.audioEl.volume = Math.max(0, Math.min(1, v)); } catch {}
    }
  }

  function setupAudioFile() {
    const a = document.createElement('audio');
    a.src = INTRO_AUDIO_URL;
    a.preload = 'auto';
    a.crossOrigin = 'anonymous';
    a.loop = false;
    a._fileAvailable = true;
    a.addEventListener('error', () => {
      // File missing or unreadable → synth fallback will be used
      a._fileAvailable = false;
    });
    STATE.audioEl = a;
  }

  /**
   * Synthesize a gothic "The Nun"-style eerie intro.
   *  - Low sub rumble (45 Hz sine)
   *  - Two detuned minor organ chords (C minor -> G minor slow shift)
   *  - Choir-like formant noise whispers
   *  - Final high "scream" pitch swell
   */
  function buildFallbackSynth() {
    const ctx = ensureCtx();
    if (!ctx) return;
    const master = STATE.masterGain;

    const g = {};

    // --- Sub rumble ---
    const sub = ctx.createOscillator();
    sub.type = 'sine';
    sub.frequency.value = 46;
    const subGain = ctx.createGain();
    subGain.gain.value = 0;
    sub.connect(subGain).connect(master);
    sub.start();

    // --- Two organ layers (minor chord pads) ---
    const chord = [261.63, 311.13, 392.0, 523.25]; // C4 + Eb4 + G4 + C5 → C minor
    const organGains = [];
    chord.forEach((f, i) => {
      const o1 = ctx.createOscillator();
      o1.type = 'sawtooth';
      o1.frequency.value = f * 0.5;
      const o2 = ctx.createOscillator();
      o2.type = 'triangle';
      o2.frequency.value = f;
      const o3 = ctx.createOscillator();
      o3.type = 'triangle';
      o3.frequency.value = f * 1.004; // slight detune for "cathodal beating"
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 1800;
      lp.Q.value = 0.8;
      const hp = ctx.createBiquadFilter();
      hp.type = 'highpass';
      hp.frequency.value = 120;
      const gn = ctx.createGain();
      gn.gain.value = 0;
      o1.connect(lp);
      o2.connect(lp);
      o3.connect(lp);
      lp.connect(hp).connect(gn).connect(master);
      o1.start(); o2.start(); o3.start();
      organGains.push(gn);

      // Slowly shift chord (half-step creepy movement)
      const start = ctx.currentTime;
      o1.frequency.setValueAtTime(f * 0.5, start);
      o2.frequency.setValueAtTime(f,       start);
      o3.frequency.setValueAtTime(f * 1.004, start);
      o1.frequency.linearRampToValueAtTime(f * 0.5 * (i % 2 ? 1.122 : 0.944), start + 3.6);
      o2.frequency.linearRampToValueAtTime(f       * (i % 2 ? 1.122 : 0.944), start + 3.6);
      o3.frequency.linearRampToValueAtTime(f * 1.004 * (i % 2 ? 1.122 : 0.944), start + 3.6);
    });

    // --- Choir "ahhh" formant noise ---
    const bufSize = Math.floor(ctx.sampleRate * 4);
    const nb = ctx.createBuffer(1, bufSize, ctx.sampleRate);
    const nd = nb.getChannelData(0);
    let last = 0;
    for (let i = 0; i < bufSize; i++) {
      const w = Math.random() * 2 - 1;
      last = (last + 0.02 * w) / 1.02;
      nd[i] = last * 3.2;
    }
    const noise = ctx.createBufferSource();
    noise.buffer = nb;
    noise.loop = true;
    const bp1 = ctx.createBiquadFilter(); bp1.type = 'bandpass'; bp1.frequency.value = 900; bp1.Q.value = 7;
    const bp2 = ctx.createBiquadFilter(); bp2.type = 'bandpass'; bp2.frequency.value = 1300; bp2.Q.value = 6;
    const bp3 = ctx.createBiquadFilter(); bp3.type = 'bandpass'; bp3.frequency.value = 2400; bp3.Q.value = 4;
    const nGain = ctx.createGain();
    nGain.gain.value = 0;
    noise.connect(bp1); noise.connect(bp2); noise.connect(bp3);
    bp1.connect(nGain); bp2.connect(nGain); bp3.connect(nGain);
    nGain.connect(master);
    noise.start();

    // --- High "scream" swell around 1.5s in ---
    const screamOsc1 = ctx.createOscillator();
    screamOsc1.type = 'sawtooth';
    screamOsc1.frequency.value = 660;
    const screamOsc2 = ctx.createOscillator();
    screamOsc2.type = 'sawtooth';
    screamOsc2.frequency.value = 880;
    const screamFilter = ctx.createBiquadFilter();
    screamFilter.type = 'bandpass';
    screamFilter.frequency.value = 1800;
    screamFilter.Q.value = 9;
    const screamGain = ctx.createGain();
    screamGain.gain.value = 0;
    screamOsc1.connect(screamFilter);
    screamOsc2.connect(screamFilter);
    screamFilter.connect(screamGain).connect(master);
    const s0 = ctx.currentTime;
    screamOsc1.frequency.setValueAtTime(660, s0);
    screamOsc2.frequency.setValueAtTime(880, s0);
    screamOsc1.frequency.exponentialRampToValueAtTime(440, s0 + 3.8);
    screamOsc2.frequency.exponentialRampToValueAtTime(580, s0 + 3.8);
    screamOsc1.start(); screamOsc2.start();

    STATE.fallbackNodes = Object.assign(g, {
      sub, subGain,
      organGains,
      noise, nGain,
      screamOsc1, screamOsc2, screamGain,
    });

    // Expose an "envelope" trigger: call this to ramp in the whole patch
    STATE.fallbackNodes.rampIn = function (startT, durMs) {
      const dur = durMs / 1000;
      const t0 = startT;

      subGain.gain.cancelScheduledValues(t0);
      subGain.gain.setValueAtTime(0, t0);
      subGain.gain.linearRampToValueAtTime(0.55, t0 + 0.4);
      subGain.gain.linearRampToValueAtTime(0.35, t0 + dur);

      organGains.forEach((gn, i) => {
        const delay = 0.12 + i * 0.06;
        gn.gain.cancelScheduledValues(t0);
        gn.gain.setValueAtTime(0, t0);
        gn.gain.linearRampToValueAtTime(0.10, t0 + delay + 0.6);
        gn.gain.linearRampToValueAtTime(0.14, t0 + dur * 0.55);
        gn.gain.linearRampToValueAtTime(0.06, t0 + dur);
      });

      nGain.gain.cancelScheduledValues(t0);
      nGain.gain.setValueAtTime(0, t0);
      nGain.gain.linearRampToValueAtTime(0.07, t0 + 0.8);
      nGain.gain.linearRampToValueAtTime(0.04, t0 + dur);

      screamGain.gain.cancelScheduledValues(t0);
      screamGain.gain.setValueAtTime(0, t0);
      screamGain.gain.linearRampToValueAtTime(0.0001, t0 + 1.2);
      screamGain.gain.linearRampToValueAtTime(0.08,   t0 + 2.1);
      screamGain.gain.linearRampToValueAtTime(0.03,   t0 + 2.7);
      screamGain.gain.linearRampToValueAtTime(0.0001, t0 + dur);
    };

    STATE.fallbackNodes.fadeOut = function (t0, durMs) {
      const dur = durMs / 1000;
      subGain.gain.linearRampToValueAtTime(0.0001, t0 + dur);
      organGains.forEach(gn => gn.gain.linearRampToValueAtTime(0.0001, t0 + dur));
      nGain.gain.linearRampToValueAtTime(0.0001, t0 + dur);
      screamGain.gain.linearRampToValueAtTime(0.0001, t0 + dur);
      // Ramp master to silence
      if (STATE.masterGain) {
        STATE.masterGain.gain.cancelScheduledValues(t0);
        STATE.masterGain.gain.linearRampToValueAtTime(0.0001, t0 + dur);
      }
    };
  }

  function playIntro() {
    const ctx = ensureCtx();
    // First: try <audio> file path (user dropped intro.mp3)
    if (STATE.audioEl && STATE.audioEl._fileAvailable !== false) {
      const p = STATE.audioEl.play();
      if (p && typeof p.catch === 'function') {
        p.catch(err => {
          console.info('[intro] File play blocked, falling back to synth', err && err.message);
          STATE.audioEl._fileAvailable = false;
          playSynthIntro();
        });
        // Fade up / down volume on the element
        try {
          STATE.audioEl.volume = 0;
          setTimeout(() => { STATE.audioEl.volume = 0.85; }, 60);
          setTimeout(() => {
            try {
              STATE.audioEl.volume = 0.85;
              // 1s fade-out toward end
              const start = performance.now();
              const iv = setInterval(() => {
                const t = (performance.now() - start) / 1000;
                if (t >= 1.0 || !STATE.audioEl) { clearInterval(iv); return; }
                try { STATE.audioEl.volume = 0.85 * (1 - t); } catch {}
              }, 50);
            } catch {}
          }, INTRO_DURATION_MS - 1000);
        } catch {}
      }
      // Resume web audio ctx if we built it
      if (ctx && ctx.state === 'suspended') ctx.resume().catch(()=>{});
      if (STATE.masterGain) {
        // Very quiet ambient from synth too (adds bottom end)
        STATE.masterGain.gain.value = 0.0;
      }
      buildFallbackSynth();
      if (STATE.fallbackNodes) {
        const t0 = ctx.currentTime;
        STATE.masterGain.gain.cancelScheduledValues(t0);
        STATE.masterGain.gain.linearRampToValueAtTime(0.0, t0 + 0.01);
        STATE.masterGain.gain.linearRampToValueAtTime(0.25, t0 + 0.4);
        STATE.fallbackNodes.rampIn(t0, INTRO_DURATION_MS);
      }
      return;
    }
    // Fallback: pure synth
    playSynthIntro();
  }

  function playSynthIntro() {
    const ctx = ensureCtx();
    if (!ctx) return;
    if (!STATE.fallbackNodes) buildFallbackSynth();
    if (!STATE.fallbackNodes) return;
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    const t0 = ctx.currentTime;
    // Master volume: file path might have set it, reset
    STATE.masterGain.gain.cancelScheduledValues(t0);
    STATE.masterGain.gain.setValueAtTime(0.0, t0);
    STATE.masterGain.gain.linearRampToValueAtTime(0.78, t0 + 0.35);
    STATE.masterGain.gain.linearRampToValueAtTime(0.72, t0 + (INTRO_DURATION_MS/1000));
    STATE.fallbackNodes.rampIn(t0, INTRO_DURATION_MS);
  }

  function stopIntro(durationMs = 800) {
    const ctx = STATE.ctx;
    // Fade file audio
    if (STATE.audioEl && STATE.audioEl._fileAvailable !== false) {
      try {
        const start = performance.now();
        const initVol = STATE.audioEl.volume;
        const iv = setInterval(() => {
          const t = (performance.now() - start) / durationMs;
          if (t >= 1 || !STATE.audioEl) {
            clearInterval(iv);
            try { STATE.audioEl.pause(); } catch {}
            return;
          }
          try { STATE.audioEl.volume = initVol * (1 - t); } catch {}
        }, 40);
      } catch {}
    }
    // Fade synth audio
    if (ctx && STATE.fallbackNodes && STATE.fallbackNodes.fadeOut) {
      STATE.fallbackNodes.fadeOut(ctx.currentTime, durationMs);
    } else if (ctx && STATE.masterGain) {
      const t0 = ctx.currentTime;
      STATE.masterGain.gain.cancelScheduledValues(t0);
      STATE.masterGain.gain.linearRampToValueAtTime(0.0001, t0 + durationMs/1000);
    }
  }

  /* ==========================================================
     3. MAIN FLOW
     ========================================================== */
  function beginExperience() {
    if (STATE.started) return;
    STATE.started = true;

    const splash = document.getElementById('intro-splash');
    const beginBtn = document.getElementById('intro-begin');
    const hint = document.querySelector('.intro-hint');
    if (beginBtn) {
      beginBtn.classList.add('started');
      beginBtn.disabled = true;
      beginBtn.textContent = 'Welcome…';
    }
    if (hint) {
      hint.style.transition = 'opacity .6s ease';
      hint.style.opacity = '0';
    }

    // Step A: start music (this is the user gesture)
    try { playIntro(); } catch (e) { console.warn(e); }

    // Step B: unlock the site-wide AudioManager's audio
    try {
      const A = window.AudioManager;
      if (A && A.unlock) A.unlock();
      else if (window.dispatchEvent) {
        // audio.js listens once on pointerdown. Dispatch a synthetic one
        // so the guard fires on the same user stack (safe, user already clicked).
        window.dispatchEvent(new Event('pointerdown'));
      }
    } catch (e) { /* noop */ }

    // Step C: ramp electric logo intensity
    logoRampUp();

    // Step D: mark splash as leaving, then hide it (matches CSS transitions)
    const transitionStart = INTRO_DURATION_MS - FADE_OUT_MS;
    setTimeout(() => {
      if (splash) splash.classList.add('leaving');
    }, transitionStart);

    setTimeout(() => {
      if (splash) splash.classList.add('hidden');
      STATE.ended = true;
      // Kill electric logo so the canvas stops rendering (save CPU)
      if (STATE.logo) {
        try { STATE.logo.destroy(); } catch {}
        STATE.logo = null;
      }
      // Fade out and discard intro audio
      stopIntro(FADE_OUT_MS + 200);
      // Unlock main volume now that intro has done its user-gesture work
      try {
        if (window.AudioManager && window.AudioManager.setVolume) {
          // Carry the volume level through
          window.AudioManager.setVolume(window.AudioManager.volume || 0.6);
        }
      } catch {}
      // Emit a global event for anything that wants to know
      document.dispatchEvent(new CustomEvent('intro:complete', { bubbles: true }));
    }, INTRO_DURATION_MS + 50);
  }

  function wire() {
    const beginBtn = document.getElementById('intro-begin');
    if (beginBtn) {
      beginBtn.addEventListener('click', beginExperience);
      beginBtn.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          beginExperience();
        }
      });
    }
    // Also allow anywhere click to start (but only if the button is visible)
    const splash = document.getElementById('intro-splash');
    if (splash) {
      splash.addEventListener('pointerdown', (e) => {
        if (STATE.started) return;
        // Don't double-fire if the click WAS on the button
        if (e.target.closest('#intro-begin')) return;
        beginExperience();
      });
    }
    // Emergency escape: Escape / Enter skips intro immediately (dev mode)
    window.addEventListener('keydown', (e) => {
      if (STATE.ended) return;
      if (e.key === 'Escape' || e.key === 'Enter') {
        if (!STATE.started) beginExperience();
      }
    });
  }

  /* ==========================================================
     BOOT
     ========================================================== */
  function init() {
    mountLogo();
    setupAudioFile();
    wire();
  }

  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  /* Debug API */
  window.IntroSplash = {
    start: beginExperience,
    get started() { return STATE.started; },
    get ended()   { return STATE.ended;   },
  };
})();
