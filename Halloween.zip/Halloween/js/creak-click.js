/* ==========================================================================
   CREAK-CLICK  (global touch/click SFX)
   Plays a short "wooden door hinge" creak on every pointerdown on the page.
   - If assets/audio/creak-click.mp3 exists → plays the file (favoured).
   - Otherwise → WebAudio-synthesized wooden-hinge / bone-click (fallback).
   - Volume linked to AudioManager.masterGain when present, else 0.4.
   - Muted respects AudioManager.muted when present.
   - 180ms internal throttle so rapid-fire clicks don't layer-storm.
   ========================================================================== */

(function () {
  'use strict';

  const FILE_PATH = 'assets/audio/creak-click.mp3';
  const THROTTLE_MS = 180;
  const BASE_DB = 0.42;

  let lastAt = 0;
  let audioEl = null;
  let fileTested = false;
  let fileWorks = false;

  function testFile() {
    if (fileTested) return;
    fileTested = true;
    const probe = new Audio();
    probe.preload = 'auto';
    probe.src = FILE_PATH;
    probe.addEventListener('canplaythrough', () => { fileWorks = true; audioEl = probe; }, { once: true });
    probe.addEventListener('error', () => { fileWorks = false; }, { once: true });
    probe.load();
  }

  function getVolume() {
    const AM = window.AudioManager;
    if (AM) {
      if (AM.muted) return 0;
      try {
        if (AM.masterGain && typeof AM.masterGain.gain === 'object' && 'value' in AM.masterGain.gain) {
          return Math.min(1, AM.masterGain.gain.value * BASE_DB);
        }
      } catch (_) { /* ignore */ }
      return typeof AM.volume === 'number' ? Math.min(1, AM.volume * BASE_DB) : BASE_DB;
    }
    return BASE_DB;
  }

  function playFile(vol) {
    if (!audioEl) return false;
    try {
      audioEl.pause();
      audioEl.currentTime = 0;
      audioEl.volume = vol;
      const p = audioEl.play();
      if (p && typeof p.catch === 'function') p.catch(() => {});
      return true;
    } catch (_) { return false; }
  }

  let ctx = null;
  function getCtx() {
    if (ctx) return ctx;
    const AM = window.AudioManager;
    if (AM && AM.ctx) { ctx = AM.ctx; return ctx; }
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    } catch (_) { ctx = null; }
    return ctx;
  }

  function playSynth(vol) {
    const c = getCtx();
    if (!c) return;
    if (c.state === 'suspended') { try { c.resume(); } catch (_) {} }
    const now = c.currentTime;
    const dur = 0.28;

    const master = c.createGain();
    master.gain.setValueAtTime(0.0001, now);
    master.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), now + 0.012);
    master.gain.exponentialRampToValueAtTime(0.0001, now + dur);

    const lp = c.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(2200, now);
    lp.frequency.exponentialRampToValueAtTime(480, now + dur);
    lp.Q.value = 2.4;

    const bp = c.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(720, now);
    bp.frequency.linearRampToValueAtTime(520, now + dur);
    bp.Q.value = 3.2;

    const osc1 = c.createOscillator();
    osc1.type = 'sawtooth';
    osc1.frequency.setValueAtTime(155, now);
    osc1.frequency.linearRampToValueAtTime(108, now + dur);

    const osc2 = c.createOscillator();
    osc2.type = 'square';
    osc2.frequency.setValueAtTime(310, now);
    osc2.frequency.linearRampToValueAtTime(190, now + dur);

    const osc2Gain = c.createGain();
    osc2Gain.gain.value = 0.28;

    const noiseBuf = c.createBuffer(1, Math.ceil(c.sampleRate * dur), c.sampleRate);
    const nd = noiseBuf.getChannelData(0);
    for (let i = 0; i < nd.length; i++) {
      const t = i / nd.length;
      const env = Math.sin(t * Math.PI) * (1 - t * 0.6);
      nd[i] = (Math.random() * 2 - 1) * 0.45 * env;
    }
    const noise = c.createBufferSource();
    noise.buffer = noiseBuf;

    const noiseGain = c.createGain();
    noiseGain.gain.value = 0.55;

    osc1.connect(bp);
    osc2.connect(osc2Gain).connect(bp);
    noise.connect(noiseGain).connect(lp);
    bp.connect(master);
    lp.connect(master);

    const AM = window.AudioManager;
    if (AM && AM.masterGain) { master.connect(AM.masterGain); }
    else { master.connect(c.destination); }

    osc1.start(now);
    osc2.start(now);
    noise.start(now);
    osc1.stop(now + dur + 0.02);
    osc2.stop(now + dur + 0.02);
    noise.stop(now + dur + 0.02);
  }

  function fire() {
    const now = performance.now();
    if (now - lastAt < THROTTLE_MS) return;
    lastAt = now;
    const vol = getVolume();
    if (vol <= 0) return;
    if (fileWorks && playFile(vol)) return;
    playSynth(vol);
  }

  /* --- hook: any real pointer down anywhere in the document (no synthetic events) */
  document.addEventListener('pointerdown', (ev) => {
    if (ev.isTrusted !== true) return;
    fire();
  }, { passive: true });

  /* --- lifecycle: wait for AudioManager unlock or any user gesture to prime AudioContext */
  window.addEventListener('load', testFile, { once: true });

  document.addEventListener('intro:complete', testFile, { once: true, passive: true });

  document.addEventListener('DOMContentLoaded', () => {
    const prime = () => {
      const c = getCtx();
      if (c && c.state === 'suspended') { try { c.resume(); } catch (_) {} }
    };
    document.addEventListener('pointerdown', prime, { once: true, passive: true });
    document.addEventListener('keydown', prime, { once: true, passive: true });
  });
})();
