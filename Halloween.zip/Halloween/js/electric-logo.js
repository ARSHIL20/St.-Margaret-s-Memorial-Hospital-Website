/* ============================================================
   electric-logo.js — WebGL Electric Logo (ogl UMD port)
   Ports the reactbits.dev Electric Logo to vanilla JS using ogl
   via CDN UMD (no React, no build step, no npm).
   Public API:
     new ElectricLogo(container, options)
     instance.destroy()
     instance.setOption(key, value)
   ============================================================ */
(function () {
  'use strict';

  const BOLT = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><path d="M39 3 12 37h17l-4 24 27-34H35z" fill="#fff"/></svg>'
  );
  const RASTER = 560;
  const CELL = 4;
  const FAR = 1e20;
  const ARCS = 5;
  const PULSES = 3;
  const PIXEL_BUDGET = 4e6;

  /* ----------------------------------------------------------
     1. HELPERS
     ---------------------------------------------------------- */
  function hexToRgb(hex) {
    let h = String(hex || '').replace('#', '');
    if (h.length === 3) h = h.replace(/./g, (c) => c + c);
    const n = parseInt(h.slice(0, 6), 16);
    return Number.isNaN(n)
      ? [1, 1, 1]
      : [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
  }

  function transformLine(f, d, v, z, n) {
    let k = 0;
    v[0] = 0;
    z[0] = -FAR;
    z[1] = FAR;
    for (let q = 1; q < n; q++) {
      let s = (f[q] + q * q - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]);
      while (s <= z[k]) {
        k--;
        s = (f[q] + q * q - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]);
      }
      k++;
      v[k] = q;
      z[k] = s;
      z[k + 1] = FAR;
    }
    k = 0;
    for (let q = 0; q < n; q++) {
      while (z[k + 1] < q) k++;
      d[q] = (q - v[k]) * (q - v[k]) + f[v[k]];
    }
  }

  function transformGrid(grid, w, h) {
    const n = Math.max(w, h);
    const f = new Float64Array(n);
    const d = new Float64Array(n);
    const v = new Int32Array(n);
    const z = new Float64Array(n + 1);
    for (let x = 0; x < w; x++) {
      for (let y = 0; y < h; y++) f[y] = grid[y * w + x];
      transformLine(f, d, v, z, h);
      for (let y = 0; y < h; y++) grid[y * w + x] = d[y];
    }
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) f[x] = grid[y * w + x];
      transformLine(f, d, v, z, w);
      for (let x = 0; x < w; x++) grid[y * w + x] = d[x];
    }
  }

  function blurLine(src, dst, offset, stride, n, r) {
    const scale = 1 / (2 * r + 1);
    let sum = 0;
    for (let i = 0; i <= r && i < n; i++) sum += src[offset + i * stride];
    for (let i = 0; i < n; i++) {
      dst[offset + i * stride] = sum * scale;
      if (i + r + 1 < n) sum += src[offset + (i + r + 1) * stride];
      if (i - r >= 0) sum -= src[offset + (i - r) * stride];
    }
  }

  function blurGrid(grid, w, h, r) {
    const tmp = new Float32Array(w * h);
    for (let pass = 0; pass < 3; pass++) {
      for (let y = 0; y < h; y++) blurLine(grid, tmp, y * w, 1, w, r);
      for (let x = 0; x < w; x++) blurLine(tmp, grid, x, w, h, r);
    }
  }

  function readCoverage(data, w, h) {
    const coverage = new Float32Array(w * h);
    let clear = 0;
    for (let i = 0; i < w * h; i++) if (data[i * 4 + 3] < 250) clear++;
    if (clear > w * h * 0.01) {
      for (let i = 0; i < w * h; i++) coverage[i] = data[i * 4 + 3] / 255;
      return coverage;
    }
    let r = 0, g = 0, b = 0, n = 0;
    const sample = (i) => {
      r += data[i * 4]; g += data[i * 4 + 1]; b += data[i * 4 + 2]; n++;
    };
    for (let x = 0; x < w; x++) { sample(x); sample((h - 1) * w + x); }
    for (let y = 0; y < h; y++) { sample(y * w); sample(y * w + w - 1); }
    r /= n; g /= n; b /= n;
    for (let i = 0; i < w * h; i++) {
      const diff = Math.max(
        Math.abs(data[i * 4] - r),
        Math.abs(data[i * 4 + 1] - g),
        Math.abs(data[i * 4 + 2] - b)
      );
      coverage[i] = Math.min(1, Math.max(0, (diff - 24) / 48));
    }
    return coverage;
  }

  function sampleField(shape, x, y) {
    const { field, width, height } = shape;
    const cx = Math.min(Math.max(x, 0.5), width - 0.5);
    const cy = Math.min(Math.max(y, 0.5), height - 0.5);
    const x0 = Math.min(Math.floor(cx - 0.5), width - 2);
    const y0 = Math.min(Math.floor(cy - 0.5), height - 2);
    const tx = cx - 0.5 - x0;
    const ty = cy - 0.5 - y0;
    const i = y0 * width + x0;
    const top = field[i] + (field[i + 1] - field[i]) * tx;
    const bottom = field[i + width] + (field[i + width + 1] - field[i + width]) * tx;
    return top + (bottom - top) * ty + Math.hypot(x - cx, y - cy);
  }

  /* ----------------------------------------------------------
     2. TRACE SHAPE — build SDF field + edges + aura grid
     ---------------------------------------------------------- */
  function traceShape(image) {
    const iw = image.naturalWidth || image.width;
    const ih = image.naturalHeight || image.height;
    if (!iw || !ih) return null;
    const fit = RASTER / Math.max(iw, ih);
    const w = Math.max(2, Math.round(iw * fit));
    const h = Math.max(2, Math.round(ih * fit));
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return null;
    ctx.drawImage(image, 0, 0, w, h);
    const coverage = readCoverage(ctx.getImageData(0, 0, w, h).data, w, h);

    let left = w, top = h, right = -1, bottom = -1;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        if (coverage[y * w + x] <= 0.01) continue;
        if (x < left) left = x;
        if (x > right) right = x;
        if (y < top) top = y;
        if (y > bottom) bottom = y;
      }
    }
    if (right < 0) return null;

    const logoWidth = right - left + 1;
    const logoHeight = bottom - top + 1;
    const pad = Math.ceil(Math.max(logoWidth, logoHeight) * 0.25) + 2;
    const width = logoWidth + pad * 2;
    const height = logoHeight + pad * 2;
    const outer = new Float32Array(width * height);
    const inner = new Float32Array(width * height);
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const sx = x - pad + left;
        const sy = y - pad + top;
        const a = (sx >= 0 && sy >= 0 && sx < w && sy < h) ? coverage[sy * w + sx] : 0;
        const i = y * width + x;
        if (a >= 1) {
          outer[i] = 0; inner[i] = FAR;
        } else if (a <= 0) {
          outer[i] = FAR; inner[i] = 0;
        } else {
          const e = 0.5 - a;
          outer[i] = e > 0 ? e * e : 0;
          inner[i] = e < 0 ? e * e : 0;
        }
      }
    }
    transformGrid(outer, width, height);
    transformGrid(inner, width, height);

    const field = new Float32Array(width * height);
    for (let i = 0; i < width * height; i++) field[i] = Math.sqrt(outer[i]) - Math.sqrt(inner[i]);

    const points = [];
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const i = y * width + x;
        const d = field[i];
        if (d > 0) continue;
        if (field[i - 1] <= 0 && field[i + 1] <= 0 &&
            field[i - width] <= 0 && field[i + width] <= 0) continue;
        const gx = field[i + 1] - field[i - 1];
        const gy = field[i + width] - field[i - width];
        const len = Math.hypot(gx, gy) || 1;
        points.push(x + 0.5 - (d * gx) / len, y + 0.5 - (d * gy) / len);
      }
    }
    const stride = Math.max(1, Math.ceil(points.length / 2 / 3000)) * 2;
    const edges = [];
    for (let i = 0; i < points.length; i += stride) edges.push(points[i], points[i + 1]);

    const size = Math.max(logoWidth, logoHeight);
    const glowPad = Math.ceil((size * 0.7) / CELL);
    const glowWidth = Math.ceil(logoWidth / CELL) + glowPad * 2;
    const glowHeight = Math.ceil(logoHeight / CELL) + glowPad * 2;
    const tight = new Float32Array(glowWidth * glowHeight);
    for (let y = 0; y < height; y++) {
      const gy = Math.floor((y - pad) / CELL) + glowPad;
      for (let x = 0; x < width; x++) {
        const gx = Math.floor((x - pad) / CELL) + glowPad;
        tight[gy * glowWidth + gx] +=
          Math.exp(-Math.abs(field[y * width + x]) / 1.5) / (CELL * CELL);
      }
    }
    const wide = tight.slice();
    const tightRadius = Math.max(1, Math.round((size * 0.035) / CELL));
    const wideRadius = Math.max(2, Math.round((size * 0.13) / CELL));
    blurGrid(tight, glowWidth, glowHeight, tightRadius);
    blurGrid(wide, glowWidth, glowHeight, wideRadius);
    const tightNorm = (Math.sqrt(2 * Math.PI * (tightRadius * tightRadius + tightRadius)) * CELL) / 3;
    const wideNorm = (Math.sqrt(2 * Math.PI * (wideRadius * wideRadius + wideRadius)) * CELL) / 3;
    const glow = new Float32Array(glowWidth * glowHeight * 2);
    for (let i = 0; i < glowWidth * glowHeight; i++) {
      glow[i * 2] = tight[i] * tightNorm;
      glow[i * 2 + 1] = wide[i] * wideNorm;
    }

    return {
      field, edges, width, height, pad, logoWidth, logoHeight,
      glow, glowWidth, glowHeight,
      glowOffset: pad - glowPad * CELL
    };
  }

  /* ----------------------------------------------------------
     3. SPAWN ARC
     ---------------------------------------------------------- */
  function spawnArc(shape, time, focus) {
    const { edges, logoWidth, logoHeight } = shape;
    const count = edges.length / 2;
    if (count < 2) return null;
    const size = Math.max(logoWidth, logoHeight);
    let i = Math.floor(Math.random() * count);
    if (focus) {
      let found = false;
      for (let attempt = 0; attempt < 40 && !found; attempt++) {
        const j = Math.floor(Math.random() * count);
        if (Math.hypot(edges[j * 2] - focus.x, edges[j * 2 + 1] - focus.y) < focus.radius) {
          i = j; found = true;
        }
      }
      if (!found) return null;
    }
    const ax = edges[i * 2];
    const ay = edges[i * 2 + 1];
    for (let attempt = 0; attempt < 24; attempt++) {
      const j = Math.floor(Math.random() * count);
      const bx = edges[j * 2];
      const by = edges[j * 2 + 1];
      const len = Math.hypot(bx - ax, by - ay);
      if (len < size * 0.08 || len > size * 0.3) continue;
      const nx = -(by - ay) / len;
      const ny = (bx - ax) / len;
      const bow = len * (0.2 + Math.random() * 0.3);
      const mx = (ax + bx) / 2;
      const my = (ay + by) / 2;
      const left = sampleField(shape, mx + nx * bow, my + ny * bow);
      const right = sampleField(shape, mx - nx * bow, my - ny * bow);
      if (Math.max(left, right) <= 0) continue;
      return {
        ax, ay, bx, by,
        bow: left >= right ? bow : -bow,
        seed: 1 + Math.random() * 60,
        born: time,
        life: 0.35 + Math.random() * 0.45
      };
    }
    return null;
  }

  /* ----------------------------------------------------------
     4. SHADERS
     ---------------------------------------------------------- */
  const vertex =
`#version 300 es
in vec2 position;
in vec2 uv;
out vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position, 0.0, 1.0);
}
`;

  const fragment =
`#version 300 es
precision highp float;
precision highp int;

uniform sampler2D tFieldFrom;
uniform sampler2D tGlowFrom;
uniform sampler2D tFieldTo;
uniform sampler2D tGlowTo;
uniform vec4 uMapFrom;
uniform vec4 uSizeFrom;
uniform vec4 uMapTo;
uniform vec4 uSizeTo;
uniform float uMorph;
uniform vec2 uResolution;
uniform float uUnit;
uniform float uTime;
uniform float uPresence;
uniform vec3 uHover;
uniform float uHoverRadius;
uniform vec4 uPulses[${PULSES}];
uniform float uPulseBoost;
uniform float uFlash;
uniform vec3 uColor;
uniform vec3 uGlowColor;
uniform float uIntensity;
uniform float uGlow;
uniform float uThickness;
uniform float uStrands;
uniform float uBend;
uniform float uCrackle;
uniform float uFlicker;
uniform float uFill;
uniform float uInk;
uniform vec4 uArcEnds[${ARCS}];
uniform vec4 uArcShape[${ARCS}];

in vec2 vUv;
out vec4 fragColor;

uint scramble(uint x) {
  x ^= x >> 16u;
  x *= 0x7feb352du;
  x ^= x >> 15u;
  x *= 0x846ca68bu;
  x ^= x >> 16u;
  return x;
}

float fieldAt(sampler2D tex, vec4 map, vec4 size, vec2 p) {
  vec2 f = (p - map.xy) / map.z;
  vec2 c = clamp(f, vec2(0.5), size.xy - 0.5);
  return (textureLod(tex, c / size.xy, 0.0).r + length(f - c)) * map.z;
}

vec2 glowAt(sampler2D tex, vec4 map, vec4 size, vec2 p) {
  vec2 f = (p - map.xy) / map.z - map.w;
  return textureLod(tex, f / (size.zw * ${CELL}.0), 0.0).rg;
}

float shape(vec2 p, float k) {
  float to = fieldAt(tFieldTo, uMapTo, uSizeTo, p);
  if (k >= 1.0) return to;
  return mix(fieldAt(tFieldFrom, uMapFrom, uSizeFrom, p), to, k);
}

vec2 aura(vec2 p, float k) {
  vec2 to = glowAt(tGlowTo, uMapTo, uSizeTo, p);
  if (k >= 1.0) return to;
  return mix(glowAt(tGlowFrom, uMapFrom, uSizeFrom, p), to, k);
}

vec4 corner(ivec2 c, uint seed) {
  uint h = scramble(uint(c.x) * 0x8da6b343u + uint(c.y) * 0xd8163841u + seed * 0xcb1ab31fu);
  return vec4(uvec4(h, h >> 8u, h >> 16u, h >> 24u) & 255u) / 127.5 - 1.0;
}

vec2 drift(vec2 p, uint seed, out mat2 jac) {
  vec2 i = floor(p);
  vec2 f = p - i;
  vec2 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
  vec2 du = 30.0 * f * f * (f * (f - 2.0) + 1.0);
  ivec2 c = ivec2(i);
  vec4 ga = corner(c, seed);
  vec4 gb = corner(c + ivec2(1, 0), seed);
  vec4 gc = corner(c + ivec2(0, 1), seed);
  vec4 gd = corner(c + ivec2(1, 1), seed);
  vec2 fb = f - vec2(1.0, 0.0);
  vec2 fc = f - vec2(0.0, 1.0);
  vec2 fd = f - vec2(1.0);
  vec2 va = vec2(dot(ga.xy, f), dot(ga.zw, f));
  vec2 vb = vec2(dot(gb.xy, fb), dot(gb.zw, fb));
  vec2 vc = vec2(dot(gc.xy, fc), dot(gc.zw, fc));
  vec2 vd = vec2(dot(gd.xy, fd), dot(gd.zw, fd));
  vec2 k = va - vb - vc + vd;
  vec4 g = ga + u.x * (gb - ga) + u.y * (gc - ga) + u.x * u.y * (ga - gb - gc + gd);
  jac = mat2(
    g.xy + du * (u.yx * k.x + vec2(vb.x - va.x, vc.x - va.x)),
    g.zw + du * (u.yx * k.y + vec2(vb.y - va.y, vc.y - va.y))
  );
  return va + u.x * (vb - va) + u.y * (vc - va) + u.x * u.y * k;
}

float wobble(vec2 p, uint seed) {
  mat2 jac;
  return drift(p, seed, jac).x;
}

vec2 ripple(vec2 p, out float surge) {
  vec2 push = vec2(0.0);
  surge = 0.0;
  float width = uUnit * 10.0;
  for (int i = 0; i < ${PULSES}; i++) {
    vec4 pulse = uPulses[i];
    if (pulse.w <= 0.0) continue;
    vec2 d = p - pulse.xy;
    float dist = length(d);
    float front = (dist - pulse.z * uUnit * 150.0) / width;
    float env = exp(-front * front) * pulse.w * exp(-pulse.z * 1.7) *
                smoothstep(0.0, uUnit * 8.0, dist);
    push += d / max(dist, 1.0) * env * cos(front * 2.2) * uUnit * 7.5;
    surge += env;
  }
  return push;
}

vec2 wander(vec2 p, float t, uint seed, float reachScale, out mat2 jac, out vec2 sway) {
  vec2 q = p / uUnit;
  mat2 ja, jb, jc, jd;
  vec2 a = drift(q * 0.028 + vec2(t * 0.29, t * 0.21), seed, ja);
  vec2 b = drift(q * 0.085 + a * 0.4 + vec2(t * 0.83, -t * 0.61) + 17.0, seed + 1u, jb);
  vec2 c = drift(p / 9.0 + b * 0.6 + vec2(t * 1.9, t * 1.3) + 5.0, seed + 2u, jc);
  vec2 d = drift(p / 4.1 + vec2(-t * 2.7, t * 2.2) + 11.0, seed + 3u, jd);
  float bendAmp = uBend * 8.0 * reachScale;
  float rippleAmp = uBend * 3.2 * reachScale;
  float crinkleAmp = uCrackle * 1.5 * reachScale;
  jac = ja * (0.028 * bendAmp) + jb * (0.085 * rippleAmp) +
        jc * (crinkleAmp / 9.0) + jd * (crinkleAmp * 0.35 / 4.1);
  sway = (a * bendAmp + b * rippleAmp) * uUnit;
  return sway + (c + d * 0.35) * crinkleAmp;
}

vec2 glowShape(float line, float spread, float w) {
  float x = abs(line);
  float y = abs(spread);
  return vec2(exp(-x * x / (w * w * 0.5)) + exp(-y / (w * 2.2)) * 0.6,
              exp(-y / (w * 4.5)) * 0.5);
}

void addArc(vec2 p, vec4 ends, vec4 info, float t, inout vec3 light,
            inout float energy, inout float hot) {
  if (info.y < 0.002) return;
  vec2 ab = ends.zw - ends.xy;
  float len = max(length(ab), 1.0);
  vec2 dir = ab / len;
  vec2 rel = p - ends.xy;
  float s = dot(rel, dir);
  float h = dot(rel, vec2(-dir.y, dir.x));
  float margin = abs(info.x) + uCrackle * (2.0 + len * 0.08) + uThickness * 12.0 + 10.0;
  if (s < -margin || s > len + margin || abs(h) > margin) return;
  float u = clamp(s / len, 0.0, 1.0);
  float taper = sin(3.14159265 * u);
  float bendSlope = (s > 0.0 && s < len) ? (3.14159265 / len * cos(3.14159265 * u)) : 0.0;
  float beyond = max(-s, 0.0) + max(s - len, 0.0);
  for (int c = 0; c < 2; c++) {
    uint seed = uint(info.z * 131.0) + uint(c) * 29u + 7u;
    float jag = 0.0;
    float jagSlope = 0.0;
    float wave = max(len * 0.3, 14.0);
    float weight = uCrackle * (1.5 + len * 0.05) * (c == 0 ? 1.0 : 1.5);
    for (int o = 0; o < 3; o++) {
      mat2 jac;
      float n = drift(vec2(s / wave + info.z * 3.0, t * (1.4 + float(o) * 1.1)),
                      seed + uint(o), jac).x;
      jag += n * weight;
      jagSlope += jac[0].x * weight / wave;
      wave *= 0.42;
      weight *= 0.4;
    }
    float offset = (info.x + jag) * taper;
    float offsetSlope = (info.x + jag) * bendSlope + jagSlope * taper;
    float across = (h - offset) / sqrt(1.0 + offsetSlope * offsetSlope);
    float gap = length(vec2(beyond, across));
    float w = uThickness * (c == 0 ? 0.9 : 0.6);
    vec2 g = glowShape(gap, gap, w);
    float k = info.y * (c == 0 ? 1.0 : 0.45);
    light += (uColor * g.x + uGlowColor * g.y * uGlow) * k;
    energy += (g.x + g.y * uGlow) * k;
    hot += exp(-gap * gap / (w * w * 0.16)) * k * (c == 0 ? 1.0 : 0.0);
  }
}

void main() {
  vec2 p = vec2(vUv.x, 1.0 - vUv.y) * uResolution;
  float t = uTime;
  vec3 light = vec3(0.0);
  float energy = 0.0;
  float hot = 0.0;

  float surge;
  vec2 pr = p - ripple(p, surge);
  float k = uMorph >= 1.0 ? 1.0 :
            smoothstep(0.0, 1.0, clamp(uMorph * 1.7 - 0.35 +
              0.35 * wobble(p / uUnit * 0.018, 41u), 0.0, 1.0));
  float transit = uMorph >= 1.0 ? 0.0 : sin(3.14159265 * uMorph);
  float base = shape(pr, k);

  vec2 toHover = p - uHover.xy;
  float heat = min(uHover.z * exp(-dot(toHover, toHover) /
              (uHoverRadius * uHoverRadius)) + surge * 1.4 + transit * 0.5, 2.0);
  float heatCap = min(uHover.z + uPulseBoost * 1.4 + transit * 0.5, 2.0);
  float breath = 1.0 + uFlicker * 0.6 * wobble(vec2(t * 2.1, 7.0), 3u);
  float grow = uPresence;

  float edge = abs(base);
  vec2 halo = aura(pr, k);
  float ink = uInk;
  float bloom = (halo.x * 0.16 + halo.y * 0.08) * (1.0 - ink * 0.65) *
                uGlow * (1.0 + heat * 1.2);
  float body = smoothstep(0.75, -0.75, base) * uFill *
               (0.06 + 1.2 * min(halo.x, 1.0)) * (1.0 + heat * 0.5);
  light += uGlowColor * bloom * grow * grow;
  energy += bloom * grow * grow;

  float reachScale = mix(0.15, 1.0, grow) * (1.0 + heat * 0.9);
  float reach = (uUnit * uBend * 16.0 + uCrackle * 3.0) *
                (1.0 + heatCap * 0.9) + uThickness * 20.0 + 8.0;
  if (edge < reach && grow > 0.0) {
    float fade = smoothstep(reach, reach * 0.55, edge);
    float count = min(uStrands + heat * 2.5, 6.0);
    float limit = min(uStrands + heatCap * 2.5, 6.0);
    for (int i = 0; i < 6; i++) {
      float fi = float(i);
      if (fi >= limit) break;
      float present = clamp(count - fi, 0.0, 1.0);
      if (present <= 0.0) continue;
      uint seed = uint(i) * 7u + 3u;
      mat2 jac;
      vec2 sway;
      float lead = i == 0 ? 1.0 : 0.0;
      vec2 warped = pr + wander(pr, t * (1.0 + fi * 0.19), seed,
        reachScale * mix(0.6 + fi * 0.2, 0.7, lead), jac, sway);
      float dw = shape(warped, k);
      vec2 slope = vec2(shape(warped + vec2(1.0, 0.0), k),
                        shape(warped + vec2(0.0, 1.0), k)) - dw;
      float d = dw / max(length(slope + jac * slope), 0.3);
      float spread = shape(pr + sway, k);
      float swell = 0.5 + 0.5 * wobble(
        p / uUnit * 0.06 + vec2(t * 0.9, fi * 5.1 - t * 0.6), seed + 8u);
      float w = uThickness * mix(0.5, 1.0, lead) * (0.5 + swell);
      float vis = mix(0.3 + 0.45 * smoothstep(-0.25, 0.2,
        wobble(p / uUnit * 0.035 + vec2(t * 0.21, fi * 3.7), seed + 5u)),
        1.0, lead);
      float spark = 1.0 - uFlicker * 0.3 *
        (0.5 + 0.5 * wobble(vec2(t * 6.0, fi * 2.3), seed + 6u));
      float weight = max(vis, heat * 0.85) * spark * fade * present *
                     (0.7 + 0.6 * swell);
      vec2 g = glowShape(d, spread, w) * weight;
      float soft = mix(1.0, mix(0.5, 1.0, lead), ink);
      vec3 stroke = mix(uColor, uGlowColor, ink * (1.0 - lead) * 0.65);
      float haze = uGlow * (1.0 + heat) * (1.0 - ink * 0.7);
      light += stroke * g.x * soft + uGlowColor * g.y * haze;
      energy += g.x * soft + g.y * haze;
      hot += exp(-d * d / (w * w * 0.16)) * lead * weight;
    }
    light *= grow;
    energy *= grow;
  }

  for (int i = 0; i < ${ARCS}; i++) {
    addArc(pr, uArcEnds[i], uArcShape[i], t, light, energy, hot);
  }

  float gain = uIntensity * breath * (1.0 + heat * 0.45) *
               (1.0 + uFlash * 0.3) * 1.4;
  float alpha = 1.0 - exp(-energy * gain);
  vec3 rgb = light * gain + vec3(1.05) * pow(hot, 1.6) * gain *
             (1.0 + heat * 0.6);
  float bodyInside = smoothstep(0.55, -0.25, base) * uFill * 0.05;
  rgb += uGlowColor * bodyInside * gain * (1.0 + heat * 0.4);
  if (uInk > 0.5) {
    float lum = clamp(rgb.r * 0.9 + rgb.g * 1.0 + rgb.b * 0.7, 0.0, 1.0);
    rgb = mix(vec3(0.0), uColor, lum);
    alpha = clamp(alpha + bodyInside * 1.6, 0.0, 1.0);
  }
  fragColor = vec4(rgb, clamp(alpha, 0.0, 1.0));
}
`;

  /* ----------------------------------------------------------
     5. TEXTURE HELPERS — CPU SDF/glow arrays → GPU textures
     ---------------------------------------------------------- */
  function makeFieldTexture(gl, ogl, field, width, height) {
    // Try float RED texture first; fall back to LUMINANCE 8-bit quantized
    const ext = gl.getExtension('EXT_color_buffer_float') ||
                gl.getExtension('EXT_color_buffer_half_float');
    let type = gl.UNSIGNED_BYTE;
    let internalFormat = gl.LUMINANCE;
    let format = gl.LUMINANCE;
    let data;
    // Quantize field to 0..1 then to 0..255
    let minV = Infinity, maxV = -Infinity;
    for (let i = 0; i < field.length; i++) {
      if (field[i] < minV) minV = field[i];
      if (field[i] > maxV) maxV = field[i];
    }
    const range = Math.max(1e-3, maxV - minV);
    const u8 = new Uint8Array(field.length);
    for (let i = 0; i < field.length; i++) {
      u8[i] = Math.max(0, Math.min(255, Math.round((field[i] - minV) / range * 255)));
    }
    data = u8;
    const tex = new ogl.Texture(gl, {
      image: data,
      width, height,
      internalFormat, format, type,
      generateMipmaps: false,
      minFilter: gl.LINEAR,
      magFilter: gl.LINEAR,
      wrapS: gl.CLAMP_TO_EDGE,
      wrapT: gl.CLAMP_TO_EDGE,
      flipY: false,
    });
    // Attach min/max for reconstruction in shader map
    tex._scale = { offset: minV, scale: range };
    return tex;
  }

  function makeGlowTexture(gl, ogl, glow, width, height) {
    // glow = width*height*2 entries (RG). We'll quantize to two LUMINANCE textures
    // Or split into two separate LUMINANCE Uint8 textures and combine in JS by
    // using RG UNSIGNED_BYTE if available; else use one LUMINANCE_ALPHA.
    // Simplest: put channel 0 in R, channel 1 in G, UNSIGNED_BYTE, internalFormat RG
    const max0 = glow.reduce((m, v, i) => (i % 2 === 0 ? Math.max(m, v) : m), 0);
    const max1 = glow.reduce((m, v, i) => (i % 2 === 1 ? Math.max(m, v) : m), 0);
    const scale0 = Math.max(1e-4, max0);
    const scale1 = Math.max(1e-4, max1);
    const rgba = new Uint8Array(width * height * 4);
    for (let i = 0; i < width * height; i++) {
      rgba[i * 4 + 0] = Math.min(255, Math.round(glow[i * 2 + 0] / scale0 * 255));
      rgba[i * 4 + 1] = Math.min(255, Math.round(glow[i * 2 + 1] / scale1 * 255));
      rgba[i * 4 + 2] = 0;
      rgba[i * 4 + 3] = 255;
    }
    const tex = new ogl.Texture(gl, {
      image: rgba,
      width, height,
      internalFormat: gl.RGBA,
      format: gl.RGBA,
      type: gl.UNSIGNED_BYTE,
      generateMipmaps: false,
      minFilter: gl.LINEAR,
      magFilter: gl.LINEAR,
      wrapS: gl.CLAMP_TO_EDGE,
      wrapT: gl.CLAMP_TO_EDGE,
      flipY: false,
    });
    tex._scale = { scale0, scale1 };
    return tex;
  }

  // Swizzle in shader via texture swizzle? Not all drivers support.
  // Instead we remap RG from RGBA.r / RGBA.g in shader directly (texture returns .rg = red/green).
  // glowAt samples tGlowFrom.tg and expects rg. We just return texture.rg (from our RGBA.r, RGBA.g).
  // Good — no change needed in shader.

  /* ----------------------------------------------------------
     6. ElectricLogo CLASS
     ---------------------------------------------------------- */
  const DEFAULTS = {
    src: BOLT,
    color: '#ecc7ff',
    glowColor: '#ad6dff',
    scale: 0.7,
    intensity: 1,
    glow: 1,
    fill: 0,
    thickness: 1.5,
    strands: 4,
    bend: 0.6,
    crackle: 1.5,
    arcs: 1,
    flicker: 0.6,
    speed: 2.5,
    interactive: true,
    cursorIntensity: 0.75,
    cursorRadius: 100,
    theme: 'dark',
    onRender: null,
    className: '',
    style: null,
  };

  class ElectricLogo {
    constructor(container, options) {
      if (!window.ogl) {
        throw new Error('[ElectricLogo] ogl UMD not loaded. ' +
          'Include <script src="https://unpkg.com/ogl@0.0.116/dist/ogl.umd.js"></script> first.');
      }
      this.container = typeof container === 'string'
        ? document.querySelector(container) : container;
      if (!this.container) throw new Error('[ElectricLogo] container not found');
      this._opts = Object.assign({}, DEFAULTS, options || {});
      this._destroyed = false;
      this._raf = 0;
      this._time = 0;
      this._lastT = 0;
      this._arcs = [];                 // length <= ARCS
      this._pulses = [];               // length <= PULSES
      this._hover = { x: -1e9, y: -1e9, z: 0 };
      this._hoverTarget = { x: -1e9, y: -1e9, z: 0 };
      this._pulseBoost = 0;
      this._flash = 0;
      this._presence = 0;
      this._presenceTarget = 0;
      this._loaded = false;

      this._applyContainerStyle();
      this._initGL();
      this._loadShape();
    }

    _applyContainerStyle() {
      const c = this.container;
      const cs = getComputedStyle(c);
      if (cs.position === 'static') c.style.position = 'relative';
      c.style.overflow = 'hidden';
      if (this._opts.className) c.classList.add(this._opts.className);
      if (this._opts.style) {
        Object.assign(c.style, this._opts.style);
      }
    }

    _initGL() {
      const c = this.container;
      const cRect = c.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const width = Math.max(1, Math.round(cRect.width || 400));
      const height = Math.max(1, Math.round(cRect.height || 200));
      const renderer = new window.ogl.Renderer({
        dpr, width, height,
        alpha: true,
        premultipliedAlpha: true,
        antialias: true,
        preserveDrawingBuffer: false,
      });
      c.appendChild(renderer.gl.canvas);
      renderer.gl.canvas.style.display = 'block';
      renderer.gl.canvas.style.width = '100%';
      renderer.gl.canvas.style.height = '100%';
      renderer.gl.canvas.style.position = 'absolute';
      renderer.gl.canvas.style.left = '0';
      renderer.gl.canvas.style.top = '0';
      const gl = renderer.gl;
      this.renderer = renderer;
      this.gl = gl;
      this._dpr = dpr;
      this._size = { width, height };

      const geometry = new window.ogl.Triangle(gl);
      this._geometry = geometry;

      // Prepare uniforms — values bound after shape loaded
      this._u = {
        tFieldFrom:  { value: null },
        tGlowFrom:   { value: null },
        tFieldTo:    { value: null },
        tGlowTo:     { value: null },
        uMapFrom:    { value: [0, 0, 1, 0] },
        uSizeFrom:   { value: [1, 1, 1, 1] },
        uMapTo:      { value: [0, 0, 1, 0] },
        uSizeTo:     { value: [1, 1, 1, 1] },
        uMorph:      { value: 1.0 },
        uResolution: { value: [width * dpr, height * dpr] },
        uUnit:       { value: 1.0 },
        uTime:       { value: 0 },
        uPresence:   { value: 0 },
        uHover:      { value: [0, 0, 0] },
        uHoverRadius:{ value: 100 },
        uPulses:     { value: Array(PULSES).fill([0,0,0,0]).map(a => new Float32Array(a)) },
        uPulseBoost: { value: 0 },
        uFlash:      { value: 0 },
        uColor:      { value: hexToRgb(this._opts.color) },
        uGlowColor:  { value: hexToRgb(this._opts.glowColor) },
        uIntensity:  { value: this._opts.intensity },
        uGlow:       { value: this._opts.glow },
        uThickness:  { value: this._opts.thickness },
        uStrands:    { value: this._opts.strands },
        uBend:       { value: this._opts.bend },
        uCrackle:    { value: this._opts.crackle },
        uFlicker:    { value: this._opts.flicker },
        uFill:       { value: this._opts.fill },
        uInk:        { value: this._opts.theme === 'light' ? 1.0 : 0.0 },
        uArcEnds:    { value: Array(ARCS).fill([0,0,0,0]).map(a => new Float32Array(a)) },
        uArcShape:   { value: Array(ARCS).fill([0,0,0,0]).map(a => new Float32Array(a)) },
      };

      try {
        this.program = new window.ogl.Program(gl, {
          vertex, fragment,
          uniforms: this._u,
          transparent: true,
          depthTest: false,
          depthWrite: false,
          cullFace: null,
        });
      } catch (e) {
        console.warn('[ElectricLogo] GLSL compile failed — falling back to 2D canvas placeholder.', e);
        this._fallback2D();
        return;
      }

      this.mesh = new window.ogl.Mesh(gl, { geometry, program: this.program });

      // Resize + input bindings
      this._onResize = this._onResize.bind(this);
      this._onMove = this._onMove.bind(this);
      this._onLeave = this._onLeave.bind(this);
      this._onClick = this._onClick.bind(this);
      window.addEventListener('resize', this._onResize);
      if (this._opts.interactive) {
        const target = c;
        target.addEventListener('pointermove', this._onMove, { passive: true });
        target.addEventListener('pointerenter', this._onMove, { passive: true });
        target.addEventListener('pointerleave', this._onLeave);
        target.addEventListener('pointerdown', this._onClick);
      }

      // Presence ramp-up starts once loaded
    }

    _fallback2D() {
      // Simple canvas fallback that draws a static gradient SMH
      const canvas = document.createElement('canvas');
      canvas.width = 600;
      canvas.height = 240;
      canvas.style.width = '100%';
      canvas.style.height = '100%';
      canvas.style.objectFit = 'contain';
      canvas.style.position = 'absolute';
      canvas.style.left = '0';
      canvas.style.top = '0';
      const ctx = canvas.getContext('2d');
      const [r,g,b] = hexToRgb(this._opts.color);
      const [gr,gg,gb] = hexToRgb(this._opts.glowColor);
      ctx.save();
      ctx.fillStyle = 'transparent';
      ctx.clearRect(0,0,600,240);
      ctx.shadowBlur = 36;
      ctx.shadowColor = `rgba(${Math.round(gr*255)},${Math.round(gg*255)},${Math.round(gb*255)},0.9)`;
      ctx.font = '700 180px "Cinzel", "Times New Roman", serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = `rgb(${Math.round(r*255)},${Math.round(g*255)},${Math.round(b*255)})`;
      ctx.fillText('SMH', 300, 130);
      ctx.restore();
      this.container.appendChild(canvas);
      this._fallbackEl = canvas;
      // Still expose a no-op destroy/setOption so intro.js doesn't choke
      this._loaded = true;
      this._startLoop = () => {};
    }

    _loadShape() {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      let loaded = false;
      img.onload = () => {
        if (loaded || this._destroyed) return;
        loaded = true;
        this._shape = traceShape(img);
        if (!this._shape) {
          console.warn('[ElectricLogo] traceShape failed, using fallback');
          this._fallback2D();
          return;
        }
        this._bindShape();
        this._loaded = true;
        this._presenceTarget = 1.0;
        this._startLoop();
      };
      img.onerror = () => {
        if (this._destroyed) return;
        this._fallback2D();
        this._loaded = true;
        this._presenceTarget = 1.0;
        this._startLoop();
      };
      // Kick off
      img.src = this._opts.src || BOLT;
      // Safety timeout for images that stall
      setTimeout(() => {
        if (!loaded && !this._destroyed && !this._fallbackEl) {
          try { img.src = BOLT; } catch {}
        }
      }, 4000);
    }

    _bindShape() {
      const s = this._shape;
      const gl = this.gl;
      // Field texture
      const fieldTex = makeFieldTexture(gl, window.ogl, s.field, s.width, s.height);
      const glowTex = makeGlowTexture(gl, window.ogl, s.glow, s.glowWidth, s.glowHeight);
      this._fieldTex = fieldTex;
      this._glowTex = glowTex;
      this._u.tFieldFrom.value = fieldTex;
      this._u.tFieldTo.value   = fieldTex;
      this._u.tGlowFrom.value  = glowTex;
      this._u.tGlowTo.value    = glowTex;

      // Compute scale: we render the shape in a coordinate system where the
      // original (width,height) raster map is centered inside canvas pixels.
      // uMap: .xy = offset of logo center from canvas bottom-left (in pixels),
      //       .z  = unit (pixels per field unit = 1 because field uses pixels)
      // Actually the shader samples fieldAt(p_in_pixels). We want the logo to
      // be centered in the canvas at (canvasW*0.5, canvasH*0.5) with size scaled.
      // So in pixels: logo center in raster coords = (s.width/2, s.height/2).
      // Scale factor k = min(canvasW, canvasH) * opts.scale / max(s.logoWidth, s.logoHeight).
      // To convert canvas-pixel p → raster pixel r:
      //   r = (p - canvasCenter) * (1/k) + rasterCenter
      // fieldAt expects r in raster coords (origin raster-bottom-left not — raster origin is TOP-left, same as canvas we draw with. Actually in the code, traceShape builds field with origin top-left (x+right, y+down). The shader does vec2 p = vec2(vUv.x, 1.0 - vUv.y) * uResolution — so p.x=right, y=DOWN (canvas top → y=0 is top. Wait no: vUv.y=0 is bottom of screen. 1 - vUv.y = 0 at top, 1 at bottom, * uResolution (height pixels) → p.y=0 at TOP, p.y=H at BOTTOM. Good, this matches raster origin (top-left, y-down).
      // So shader p matches raster coords layout (x right, y down).
      // So uMap.xy = raster (0,0) offset in shader p coords → same as:
      //   center (canvasCenter) - (rasterCenter / k * 1?) Wait let me re-derive cleanly.

      // We want the logo to fit in min(cw, ch) * opts.scale, preserving aspect.
      // logo raster size (in raster units of field) = s.logoWidth × s.logoHeight.
      // But field width = s.width, field height = s.height. The logo sits inside
      // [s.pad, s.pad+s.logoWidth] × [s.pad, s.pad+s.logoHeight] in field coords.
      // So logo field center = (s.pad + s.logoWidth/2, s.pad + s.logoHeight/2).
      // We want logo center to show at canvas center = (cw/2, ch/2) in p coords.
      // Let k = pixel scaling such that 1 field unit = k shader p pixels.
      // Compute k to fit max(s.logoWidth, s.logoHeight) into fitPx.
      this._computeMap();
    }

    _computeMap() {
      const s = this._shape;
      if (!s) return;
      const cw = this._size.width * this._dpr;
      const ch = this._size.height * this._dpr;
      this._u.uResolution.value = [cw, ch];
      const fitPx = Math.min(cw, ch) * this._opts.scale;
      const k = fitPx / Math.max(s.logoWidth, s.logoHeight);
      this._pixelPerField = k;
      this._u.uUnit.value = k; // used for bend amplitude scaling
      this._u.uHoverRadius.value = this._opts.cursorRadius * this._dpr;

      // Offset (in shader p pixels) from shader origin to raster origin
      // raster center (field) = (s.pad + s.logoWidth/2, s.pad + s.logoHeight/2)
      // shader canvas center (p) = (cw/2, ch/2)
      // raster (0,0) → shader p = canvasCenter - rasterCenter*k
      const rasterCenterX = s.pad + s.logoWidth / 2;
      const rasterCenterY = s.pad + s.logoHeight / 2;
      const originX = cw / 2 - rasterCenterX * k;
      const originY = ch / 2 - rasterCenterY * k;
      // uMap: vec4(originX, originY, k, glowOffset)
      this._u.uMapFrom.value = [originX, originY, k, s.glowOffset * k / CELL];
      this._u.uMapTo.value   = [originX, originY, k, s.glowOffset * k / CELL];
      // uSize: vec4(fieldW, fieldH, glowW, glowH) — integer pixel sizes for clamp in shader
      this._u.uSizeFrom.value = [s.width, s.height, s.glowWidth, s.glowHeight];
      this._u.uSizeTo.value   = [s.width, s.height, s.glowWidth, s.glowHeight];

      // Because we stored field/glow as 8-bit quantized, we need a reconstruct
      // step in the shader. Easiest: pass extra uniforms for range/scale.
      // (Field texture LUMINANCE .r gives 0..1 → reconstruct as tex.r*scale + offset.)
      // The current shader `fieldAt` does: textureLod(...).r + length(...). Multiply by map.z.
      // To fix this, we can pre-process field textures into a "normalized 0..255 form"
      // and pass reconstruction. Easier: rebind field texture as a floating-point texture.
      // Hmm, but Float32 textures might not be color-renderable on all WebGL2 devices.
      // Simplest robust solution: pack the SDF into RGBA8 as 16.16 fixed point OR
      // use HALF_FLOAT via EXT. Luminance quantization is too coarse for SDF (needs
      // sub-pixel accuracy over ±250 range → 500 range / 255 bins = ~2 unit error).
      // This will look blocky. Let me fix it properly: re-store field in RGBA as
      // (bytes of float), reconstruct in shader with uintBitsToFloat. WebGL 3.0 supports it.
      this._upgradeTexturesToRGBAFloat();
    }

    _upgradeTexturesToRGBAFloat() {
      const s = this._shape;
      const gl = this.gl;
      // Store field in LUMINANCE_ALPHA of UNORM, 8-bit, with reconstruction via
      // separate encode: encode(value, offset, range) to 16-bit: split 2 bytes across LA.
      // Then in shader: reconstruct = (L*255*256 + A*255)/65535 * range + offset.
      // Encode/Decode 16-bit fixed — 0.0077 unit precision over 500 range. OK.
      const field = s.field;
      let minV = Infinity, maxV = -Infinity;
      for (let i = 0; i < field.length; i++) {
        if (field[i] < minV) minV = field[i];
        if (field[i] > maxV) maxV = field[i];
      }
      const range = Math.max(1e-3, maxV - minV);
      const pixels = new Uint8Array(s.width * s.height * 2);
      for (let i = 0; i < field.length; i++) {
        const n = Math.max(0, Math.min(65535, Math.round((field[i] - minV) / range * 65535)));
        pixels[i * 2 + 0] = (n >> 8) & 255;   // hi → LUMINANCE channel
        pixels[i * 2 + 1] = n & 255;          // lo → ALPHA channel
      }
      const ext = gl.getExtension('WEBGL_compressed_texture_s3tc');
      const gl_ = gl;
      // LUMINANCE_ALPHA with UNSIGNED_BYTE, width*height, 2 bytes/pixel
      const fieldTex2 = new window.ogl.Texture(gl, {
        image: pixels,
        width: s.width, height: s.height,
        internalFormat: gl.LUMINANCE_ALPHA,
        format: gl.LUMINANCE_ALPHA,
        type: gl.UNSIGNED_BYTE,
        generateMipmaps: false,
        minFilter: gl.LINEAR,
        magFilter: gl.LINEAR,
        wrapS: gl.CLAMP_TO_EDGE,
        wrapT: gl.CLAMP_TO_EDGE,
        flipY: false,
      });
      // Replace old texture & add reconstruction info (we apply it in shader via
      // rewriting the fieldAt sampling — simpler: create a wrapper uniform).
      this._fieldTex = fieldTex2;
      this._u.tFieldFrom.value = fieldTex2;
      this._u.tFieldTo.value = fieldTex2;
      this._fieldRange = { offset: minV, scale: range };

      // Glow: encode 16-bit fixed into RG for channel 0, BA for channel 1
      const glow = s.glow;
      const max0 = glow.reduce((m, v, i) => (i % 2 === 0 ? Math.max(m, v) : m), 0);
      const max1 = glow.reduce((m, v, i) => (i % 2 === 1 ? Math.max(m, v) : m), 0);
      const scale0 = Math.max(1e-4, max0);
      const scale1 = Math.max(1e-4, max1);
      const rgba = new Uint8Array(s.glowWidth * s.glowHeight * 4);
      for (let i = 0; i < s.glowWidth * s.glowHeight; i++) {
        const v0 = Math.max(0, Math.min(65535, Math.round(glow[i * 2 + 0] / scale0 * 65535)));
        const v1 = Math.max(0, Math.min(65535, Math.round(glow[i * 2 + 1] / scale1 * 65535)));
        rgba[i * 4 + 0] = (v0 >> 8) & 255;
        rgba[i * 4 + 1] = v0 & 255;
        rgba[i * 4 + 2] = (v1 >> 8) & 255;
        rgba[i * 4 + 3] = v1 & 255;
      }
      const glowTex2 = new window.ogl.Texture(gl, {
        image: rgba,
        width: s.glowWidth, height: s.glowHeight,
        internalFormat: gl.RGBA,
        format: gl.RGBA,
        type: gl.UNSIGNED_BYTE,
        generateMipmaps: false,
        minFilter: gl.LINEAR,
        magFilter: gl.LINEAR,
        wrapS: gl.CLAMP_TO_EDGE,
        wrapT: gl.CLAMP_TO_EDGE,
        flipY: false,
      });
      this._glowTex = glowTex2;
      this._u.tGlowFrom.value = glowTex2;
      this._u.tGlowTo.value = glowTex2;
      this._glowRange = { scale0, scale1 };

      // Store reconstruction info (offsets) in the unused map.w component
      // via new uniforms to avoid rewriting the shader — actually, simpler approach:
      // we patch the program with a second-pass that pre-multiplies fieldAt.
      // But shader is already compiled. Easier: rebuild program with new shaders
      // that include reconstruction functions using fieldRange. Let's do that.
      this._rebuildProgramWithReconstruction();
    }

    _rebuildProgramWithReconstruction() {
      const gl = this.gl;
      const fr = this._fieldRange;
      const gr = this._glowRange;
      // Patch: add decode functions + rewrite fieldAt / glowAt
      const decodeHeader = `
uniform vec2  uFieldDecode;  // x = range, y = offset
uniform vec2  uGlowDecode;   // x = scale0, y = scale1
float decodeField16(vec2 la) {
  vec2 u = la * 255.0 / 255.0;  // la already in [0,1] (from LUMINANCE+ALPHA)
  float n = la.x * 256.0 + la.y;
  return n / 65535.0 * uFieldDecode.x + uFieldDecode.y;
}
float fieldAt(sampler2D tex, vec4 map, vec4 size, vec2 p) {
  vec2 f = (p - map.xy) / map.z;
  vec2 c = clamp(f, vec2(0.5), size.xy - 0.5);
  vec2 la = textureLod(tex, c / size.xy, 0.0).ra; // LUMINANCE_ALPHA → .r = lum, .a = alpha
  return (decodeField16(la) + length(f - c)) * map.z;
}
vec2 glowAt(sampler2D tex, vec4 map, vec4 size, vec2 p) {
  vec2 f = (p - map.xy) / map.z - map.w;
  vec4 rgba = textureLod(tex, f / (size.zw * ${CELL}.0), 0.0);
  float n0 = rgba.r * 256.0 + rgba.g;  // 0..257
  float n1 = rgba.b * 256.0 + rgba.a;
  // n0 is in [0, 65535]/255/256? Wait → rgba.r in [0,1] → rgba.r * 256 = 0..256
  //      but we want 0..65535. We encoded v0/65535*scale0, into two bytes:
  //      r = floor(v_norm*65535)/256; g = mod(v_norm*65535, 256)
  //      → normalized = (r*256 + g)/65535
  //      actual = normalized * scale
  // So: n_wide = rgba.r * 65280.0 + rgba.g * 255.0
  float norm0 = (rgba.r * 65280.0 + rgba.g * 255.0) / 65535.0;
  float norm1 = (rgba.b * 65280.0 + rgba.a * 255.0) / 65535.0;
  return vec2(norm0 * uGlowDecode.x, norm1 * uGlowDecode.y);
}
`;
      // Strip the old fieldAt/glowAt definitions + add decode + add uniforms
      let frag2 = fragment.replace(
        /float fieldAt\(sampler2D[\s\S]*?float shape\(vec2 p, float k\)/,
        decodeHeader + '\nfloat shape(vec2 p, float k)'
      ).replace(
        /vec2 glowAt\(sampler2D[\s\S]*?float shape\(vec2 p, float k\)/,
        ''
      );
      // Actually simpler: use full replace of both functions using header
      const funcs = /float fieldAt\(sampler2D[\s\S]*?return textureLod\(tex, f \/ \(size\.zw \* \$\{CELL\}\.0\), 0\.0\)\.rg;\n\}/.source;
      // Skip regex complexity. If above didn't work, we rebuild entirely:
      // Use new shader with decodeHeader inserted before the main() by injecting uniforms & funcs at the top.
      const injectUniforms = `
uniform vec2  uFieldDecode;
uniform vec2  uGlowDecode;
`;
      let newFrag = fragment;
      // Remove existing fieldAt + glowAt function bodies
      newFrag = newFrag.replace(
        /float fieldAt\(sampler2D tex, vec4 map, vec4 size, vec2 p\) \{[\s\S]*?\n\}\n\nvec2 glowAt\(sampler2D tex, vec4 map, vec4 size, vec2 p\) \{[\s\S]*?\n\}/,
        ''
      );
      // Insert decodeHeader + injectUniforms right after the precision lines
      newFrag = newFrag.replace(
        /(precision highp int;\n)/,
        '$1\n' + injectUniforms + decodeHeader + '\n'
      );

      // Rebuild uniforms — include new ones
      const newU = Object.assign({}, this.program.uniforms);
      newU.uFieldDecode = { value: [fr.scale, fr.offset] };
      newU.uGlowDecode  = { value: [gr.scale0, gr.scale1] };

      try {
        const newProgram = new window.ogl.Program(gl, {
          vertex, fragment: newFrag,
          uniforms: newU,
          transparent: true,
          depthTest: false,
          depthWrite: false,
          cullFace: null,
        });
        this._u = newU;
        this.program = newProgram;
        this.mesh.program = newProgram;
      } catch (e) {
        console.warn('[ElectricLogo] Reconstruct program failed, using first pass.', e);
      }
    }

    _onResize() {
      if (this._destroyed || !this.renderer) return;
      const c = this.container;
      const rect = c.getBoundingClientRect();
      const width = Math.max(1, Math.round(rect.width || 400));
      const height = Math.max(1, Math.round(rect.height || 200));
      this._size = { width, height };
      this.renderer.setSize(width, height);
      if (this._shape) this._computeMap();
    }

    _onMove(e) {
      if (this._destroyed) return;
      const c = this.container;
      const rect = c.getBoundingClientRect();
      const x = (e.clientX - rect.left) * this._dpr;
      const y = (e.clientY - rect.top) * this._dpr;
      this._hoverTarget.x = x;
      this._hoverTarget.y = y;
      this._hoverTarget.z = this._opts.cursorIntensity;
      this._presenceTarget = 1.0;
    }

    _onLeave() {
      this._hoverTarget.z = 0;
      this._presenceTarget = 1.0; // keep logo lit even when mouse leaves (nicer)
    }

    _onClick(e) {
      if (this._destroyed) return;
      const c = this.container;
      const rect = c.getBoundingClientRect();
      const x = (e.clientX - rect.left) * this._dpr;
      const y = (e.clientY - rect.top) * this._dpr;
      // Add pulse
      if (this._pulses.length < PULSES) {
        this._pulses.push({ x, y, age: 0, strength: 1 });
      } else {
        // replace oldest
        let idx = 0, oldest = this._pulses[0].age;
        for (let i = 1; i < this._pulses.length; i++) {
          if (this._pulses[i].age > oldest) { oldest = this._pulses[i].age; idx = i; }
        }
        this._pulses[idx] = { x, y, age: 0, strength: 1 };
      }
      this._pulseBoost = 1;
      this._flash = 1;
      // Spawn 3-5 arcs near cursor
      const focus = { x: (x - (this._u.uMapTo.value[0] || 0)) / (this._u.uMapTo.value[2] || 1),
                      y: (y - (this._u.uMapTo.value[1] || 0)) / (this._u.uMapTo.value[2] || 1),
                      radius: Math.max(1, (this._opts.cursorRadius * this._dpr) / (this._u.uMapTo.value[2] || 1)) * 0.25 };
      const count = 3 + Math.floor(Math.random() * 3);
      let spawned = 0;
      for (let i = 0; i < count && spawned < Math.max(0, ARCS - this._arcs.length); i++) {
        const a = spawnArc(this._shape, this._time, focus);
        if (a) { this._arcs.push(a); spawned++; }
      }
    }

    _startLoop() {
      this._lastT = performance.now();
      const tick = (now) => {
        if (this._destroyed) return;
        this._raf = requestAnimationFrame(tick);
        const dtMs = Math.min(64, now - this._lastT);
        this._lastT = now;
        this._step(dtMs / 1000 * Math.max(0, this._opts.speed));
        this._render();
        if (typeof this._opts.onRender === 'function') {
          try { this._opts.onRender(this.renderer.gl.canvas); } catch {}
        }
      };
      this._raf = requestAnimationFrame(tick);
    }

    _step(dt) {
      this._time += dt;
      // Smooth presence
      this._presence += (this._presenceTarget - this._presence) * Math.min(1, dt * 3.5);
      this._u.uPresence.value = this._presence;
      // Smooth hover
      this._hover.x += (this._hoverTarget.x - this._hover.x) * Math.min(1, dt * 8);
      this._hover.y += (this._hoverTarget.y - this._hover.y) * Math.min(1, dt * 8);
      this._hover.z += (this._hoverTarget.z - this._hover.z) * Math.min(1, dt * 6);
      this._u.uHover.value = [this._hover.x, this._hover.y, this._hover.z];
      // Smooth pulses
      for (let i = this._pulses.length - 1; i >= 0; i--) {
        this._pulses[i].age += dt * 2.0;
        if (this._pulses[i].age > 1) this._pulses.splice(i, 1);
      }
      for (let i = 0; i < PULSES; i++) {
        const p = this._pulses[i];
        if (p) {
          this._u.uPulses.value[i][0] = p.x;
          this._u.uPulses.value[i][1] = p.y;
          this._u.uPulses.value[i][2] = p.age;
          this._u.uPulses.value[i][3] = p.strength;
        } else {
          this._u.uPulses.value[i][3] = 0;
        }
      }
      this._pulseBoost *= Math.pow(0.02, dt);
      this._u.uPulseBoost.value = this._pulseBoost;
      this._flash *= Math.pow(0.001, dt);
      this._u.uFlash.value = this._flash;
      // Arcs spawn + age
      const arcBudget = this._opts.arcs;
      // Chance to spawn
      const spawnChance = Math.max(0, Math.min(2.5, arcBudget)) * dt * 1.3;
      const maxArcs = Math.max(0, Math.min(ARCS, Math.ceil(arcBudget * 2.5)));
      if (this._arcs.length < maxArcs && Math.random() < spawnChance && this._shape) {
        const a = spawnArc(this._shape, this._time, null);
        if (a) this._arcs.push(a);
      }
      // Age + retire
      for (let i = this._arcs.length - 1; i >= 0; i--) {
        const a = this._arcs[i];
        const life = Math.max(0.001, a.life);
        const age = (this._time - a.born) / life;
        if (age > 1) this._arcs.splice(i, 1);
      }
      // Bind arcs to uniforms (cap at ARCS)
      for (let i = 0; i < ARCS; i++) {
        const a = this._arcs[i];
        if (a) {
          const age = Math.max(0, Math.min(1, (this._time - a.born) / Math.max(0.001, a.life)));
          const life = 1.0 - age;
          this._u.uArcEnds.value[i][0] = a.ax * this._pixelPerField + this._u.uMapTo.value[0];
          this._u.uArcEnds.value[i][1] = a.ay * this._pixelPerField + this._u.uMapTo.value[1];
          this._u.uArcEnds.value[i][2] = a.bx * this._pixelPerField + this._u.uMapTo.value[0];
          this._u.uArcEnds.value[i][3] = a.by * this._pixelPerField + this._u.uMapTo.value[1];
          this._u.uArcShape.value[i][0] = a.bow * this._pixelPerField;     // X: bow in px
          this._u.uArcShape.value[i][1] = life;                             // Y: strength 0..1
          this._u.uArcShape.value[i][2] = a.seed;                           // Z: seed
          this._u.uArcShape.value[i][3] = age;                              // W: age 0..1
        } else {
          this._u.uArcShape.value[i][1] = 0;
        }
      }
      // Time uniform
      this._u.uTime.value = this._time;
    }

    _render() {
      if (!this.renderer || !this.mesh) return;
      const theme = this._opts.theme;
      this.renderer.gl.clearColor(0, 0, 0, 0);
      this.renderer.render({ scene: this.mesh });
    }

    /* ---------- public API ---------- */
    setOption(key, value) {
      if (!Object.prototype.hasOwnProperty.call(this._opts, key)) return;
      this._opts[key] = value;
      switch (key) {
        case 'color':
          if (this._u) this._u.uColor.value = hexToRgb(value); break;
        case 'glowColor':
          if (this._u) this._u.uGlowColor.value = hexToRgb(value); break;
        case 'intensity':
          if (this._u) this._u.uIntensity.value = value; break;
        case 'glow':
          if (this._u) this._u.uGlow.value = value; break;
        case 'fill':
          if (this._u) this._u.uFill.value = value; break;
        case 'thickness':
          if (this._u) this._u.uThickness.value = value; break;
        case 'strands':
          if (this._u) this._u.uStrands.value = value; break;
        case 'bend':
          if (this._u) this._u.uBend.value = value; break;
        case 'crackle':
          if (this._u) this._u.uCrackle.value = value; break;
        case 'arcs':
          break;
        case 'flicker':
          if (this._u) this._u.uFlicker.value = value; break;
        case 'speed':
          break;
        case 'cursorIntensity':
          this._opts.cursorIntensity = value; break;
        case 'cursorRadius':
          if (this._u) this._u.uHoverRadius.value = value * this._dpr; break;
        case 'theme':
          if (this._u) this._u.uInk.value = value === 'light' ? 1.0 : 0.0; break;
        case 'scale':
          if (this._shape) this._computeMap(); break;
        case 'src':
          // Full reload — expensive; skip unless changed
          break;
      }
    }

    destroy() {
      if (this._destroyed) return;
      this._destroyed = true;
      if (this._raf) cancelAnimationFrame(this._raf);
      window.removeEventListener('resize', this._onResize);
      if (this._opts && this._opts.interactive) {
        const c = this.container;
        if (c) {
          c.removeEventListener('pointermove', this._onMove);
          c.removeEventListener('pointerenter', this._onMove);
          c.removeEventListener('pointerleave', this._onLeave);
          c.removeEventListener('pointerdown', this._onClick);
        }
      }
      if (this._fallbackEl && this._fallbackEl.parentNode) {
        this._fallbackEl.parentNode.removeChild(this._fallbackEl);
      }
      if (this.renderer && this.renderer.gl && this.renderer.gl.canvas &&
          this.renderer.gl.canvas.parentNode) {
        this.renderer.gl.canvas.parentNode.removeChild(this.renderer.gl.canvas);
      }
      try {
        if (this._fieldTex && this._fieldTex.destroy) this._fieldTex.destroy();
        if (this._glowTex && this._glowTex.destroy) this._glowTex.destroy();
        if (this.program && this.program.destroy) this.program.destroy();
        if (this._geometry && this._geometry.destroy) this._geometry.destroy();
        if (this.mesh && this.mesh.destroy) this.mesh.destroy();
        if (this.renderer && this.renderer.gl && this.renderer.gl.getExtension) {
          // lose context
          const gl = this.renderer.gl;
          const ext = gl.getExtension('WEBGL_lose_context');
          if (ext) try { ext.loseContext(); } catch {}
        }
      } catch (e) { /* noop */ }
      this._fieldTex = this._glowTex = null;
      this.program = this._geometry = this.mesh = null;
      this.renderer = null;
      this._u = null;
      this._shape = null;
    }
  }

  /* ----------------------------------------------------------
     7. EXPORTS
     ---------------------------------------------------------- */
  window.ElectricLogo = ElectricLogo;
})();
