/* =================================================================
   audio.js — SOUND MANAGER (Web Audio API, all synthesized)
   -----------------------------------------------------------------
   All audio is procedural (no external asset files required):
     - Layer 0 : Hospital hum L1 (60Hz transformer + AC noise)
     - Layer 1 : Distant beeps L1+ (heart monitor blips)
     - Layer 2 : Footsteps / gurney squeaks L3+
     - Layer 3 : Whisper textures L7+
     - Layer 4 : Heartbeat L7+, synced to corruption level
     - Stings  : Receptionist ping, daredevil jumpscare, finale
   HOW TO EXTEND:
     1. Add a new layer: create a setupLayerX() function, call it
        from `buildLayers()`, and add level logic to `applyLevelGain()`.
     2. Replace with real files: set AudioManager.useBuffers = true and
        drop files into assets/audio named exactly as the layer keys
        (hum.wav, beeps.wav, squeaks.wav, whispers.wav, heartbeat.wav).
        init() will auto-load them via <audio> tags.
   ================================================================= */
(function () {
  'use strict';

  const C = window.CorruptionState;
  if (!C) throw new Error('audio.js requires corruption.js first');

  /* ---------- STATE ---------- */
  const MGR = {
    ctx: null,
    masterGain: null,
    musicGain: null,   // ambience layers
    sfxGain: null,     // one-shot stings
    layers: {},        // layerId → {node, gain, running: bool}
    unlocked: false,
    muted: false,
    volume: 0.6,
    _tickHandle: null,
  };

  /* ---------- NOISE BUILDER ---------- */
  function makeNoiseBuffer(seconds = 2, type = 'white') {
    const ctx = MGR.ctx;
    const buf = ctx.createBuffer(1, ctx.sampleRate * seconds, ctx.sampleRate);
    const data = buf.getChannelData(0);
    let lastOut = 0;
    for (let i = 0; i < data.length; i++) {
      if (type === 'white') {
        data[i] = (Math.random() * 2 - 1);
      } else if (type === 'pink') {
        const white = Math.random() * 2 - 1;
        lastOut = (lastOut + 0.02 * white) / 1.02;
        data[i] = lastOut * 3.5;
      } else if (type === 'brown') {
        const white = Math.random() * 2 - 1;
        lastOut = (lastOut + (0.02 * white)) / 1.02;
        data[i] = lastOut * 3;
      }
    }
    return buf;
  }

  /* ---------- LAYER 0: HUM (60Hz transformer + AC) ---------- */
  function setupHum() {
    const ctx = MGR.ctx;
    const gain = ctx.createGain();
    gain.gain.value = 0;
    gain.connect(MGR.musicGain);

    const osc1 = ctx.createOscillator();
    osc1.type = 'sine';
    osc1.frequency.value = 60;
    const og1 = ctx.createGain();
    og1.gain.value = 0.08;
    osc1.connect(og1).connect(gain);

    const osc2 = ctx.createOscillator();
    osc2.type = 'sine';
    osc2.frequency.value = 120;
    const og2 = ctx.createGain();
    og2.gain.value = 0.03;
    osc2.connect(og2).connect(gain);

    // Pink noise for "air conditioner" hiss
    const noise = ctx.createBufferSource();
    noise.buffer = makeNoiseBuffer(4, 'pink');
    noise.loop = true;
    const nGain = ctx.createGain();
    nGain.gain.value = 0.015;
    const nFilter = ctx.createBiquadFilter();
    nFilter.type = 'lowpass';
    nFilter.frequency.value = 800;
    noise.connect(nFilter).connect(nGain).connect(gain);

    osc1.start();
    osc2.start();
    noise.start();

    MGR.layers.hum = { node: [osc1, osc2, noise], gain, running: true,
      update: (lvl) => {
        const base = lvl < 1 ? 0.0 : lvl < 3 ? 0.45 : lvl < 5 ? 0.7 : 1.0;
        gain.gain.cancelScheduledValues(ctx.currentTime);
        gain.gain.linearRampToValueAtTime(base, ctx.currentTime + 2);
      }
    };
  }

  /* ---------- LAYER 1: MONITOR BEEPS ---------- */
  function setupBeeps() {
    const ctx = MGR.ctx;
    const gain = ctx.createGain();
    gain.gain.value = 0;
    gain.connect(MGR.musicGain);

    let last = 0;
    const interval = () => 900 + Math.random() * 1400; // ms between beeps

    function beep() {
      if (!MGR.unlocked) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = 880 + Math.random() * 120;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, now);
      g.gain.linearRampToValueAtTime(0.12, now + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.18);
      osc.connect(g).connect(gain);
      osc.start(now);
      osc.stop(now + 0.22);

      // Occasional "flatline" double-beep at higher corruption
      if (C.level >= 6 && Math.random() < 0.05) {
        const o2 = ctx.createOscillator();
        o2.type = 'sawtooth';
        o2.frequency.value = 220;
        const g2 = ctx.createGain();
        g2.gain.setValueAtTime(0, now + 0.25);
        g2.gain.linearRampToValueAtTime(0.08, now + 0.27);
        g2.gain.exponentialRampToValueAtTime(0.0001, now + 1.1);
        o2.connect(g2).connect(gain);
        o2.start(now + 0.25);
        o2.stop(now + 1.2);
      }
      last = Date.now();
    }
    function tick() {
      if (Date.now() - last > interval()) beep();
    }
    MGR._beepHandle = setInterval(tick, 150);

    MGR.layers.beeps = { gain, running: true,
      update: (lvl) => {
        const base = lvl < 2 ? 0.0 : lvl < 5 ? 0.35 : lvl < 8 ? 0.55 : 0.7;
        gain.gain.cancelScheduledValues(ctx.currentTime);
        gain.gain.linearRampToValueAtTime(base, ctx.currentTime + 2);
      },
      teardown: () => clearInterval(MGR._beepHandle),
    };
  }

  /* ---------- LAYER 2: GURNEY SQUEAKS + FOOTSTEPS ---------- */
  function setupSqueaks() {
    const ctx = MGR.ctx;
    const gain = ctx.createGain();
    gain.gain.value = 0;
    gain.connect(MGR.musicGain);

    function squeak() {
      const now = ctx.currentTime;
      const dur = 0.6 + Math.random() * 0.6;
      const osc = ctx.createOscillator();
      osc.type = 'sawtooth';
      const fStart = 300 + Math.random() * 400;
      osc.frequency.setValueAtTime(fStart, now);
      osc.frequency.exponentialRampToValueAtTime(fStart * 0.4, now + dur);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, now);
      g.gain.linearRampToValueAtTime(0.05, now + dur * 0.1);
      g.gain.linearRampToValueAtTime(0.04, now + dur * 0.5);
      g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
      const filt = ctx.createBiquadFilter();
      filt.type = 'bandpass';
      filt.frequency.value = 1200;
      filt.Q.value = 4;
      osc.connect(filt).connect(g).connect(gain);
      osc.start(now);
      osc.stop(now + dur + 0.05);
    }
    function footstep() {
      const now = ctx.currentTime;
      const buf = ctx.createBuffer(1, ctx.sampleRate * 0.1, ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random()*2-1) * (1 - i/d.length);
      const src = ctx.createBufferSource();
      src.buffer = buf;
      const filt = ctx.createBiquadFilter();
      filt.type = 'lowpass';
      filt.frequency.value = 320;
      const g = ctx.createGain();
      g.gain.value = 0.3;
      src.connect(filt).connect(g).connect(gain);
      src.start(now);
    }
    let nextSqueak = Date.now() + 6000;
    let nextStep = Date.now() + 4000;
    MGR._squeakHandle = setInterval(() => {
      const n = Date.now();
      if (n > nextSqueak) { squeak(); nextSqueak = n + (5000 + Math.random() * 10000); }
      if (n > nextStep)   { footstep(); nextStep = n + (3000 + Math.random() * 7000); }
    }, 500);

    MGR.layers.squeaks = { gain, running: true,
      update: (lvl) => {
        const base = lvl < 3 ? 0.0 : lvl < 6 ? 0.5 : lvl < 9 ? 0.75 : 0.95;
        gain.gain.cancelScheduledValues(ctx.currentTime);
        gain.gain.linearRampToValueAtTime(base, ctx.currentTime + 2);
      },
      teardown: () => clearInterval(MGR._squeakHandle),
    };
  }

  /* ---------- LAYER 3: WHISPERS (formant-like swept noise) ---------- */
  function setupWhispers() {
    const ctx = MGR.ctx;
    const gain = ctx.createGain();
    gain.gain.value = 0;
    gain.connect(MGR.musicGain);

    function whisper() {
      const now = ctx.currentTime;
      const dur = 1.4 + Math.random() * 1.4;
      // Noise through two formant bandpass filters
      const noise = ctx.createBufferSource();
      noise.buffer = makeNoiseBuffer(dur + 0.5, 'brown');
      const nGain = ctx.createGain();
      nGain.gain.setValueAtTime(0, now);
      nGain.gain.linearRampToValueAtTime(0.45, now + dur * 0.25);
      nGain.gain.linearRampToValueAtTime(0.2, now + dur * 0.7);
      nGain.gain.exponentialRampToValueAtTime(0.0001, now + dur);

      const f1 = ctx.createBiquadFilter();
      f1.type = 'bandpass'; f1.Q.value = 8;
      f1.frequency.setValueAtTime(500 + Math.random()*200, now);
      f1.frequency.linearRampToValueAtTime(900 + Math.random()*300, now + dur*0.5);
      f1.frequency.linearRampToValueAtTime(700, now + dur);

      const f2 = ctx.createBiquadFilter();
      f2.type = 'bandpass'; f2.Q.value = 6;
      f2.frequency.setValueAtTime(1400 + Math.random()*400, now);
      f2.frequency.linearRampToValueAtTime(2000 + Math.random()*500, now + dur*0.6);

      noise.connect(f1);
      noise.connect(f2);
      f1.connect(nGain);
      f2.connect(nGain);
      nGain.connect(gain);
      noise.start(now);
      noise.stop(now + dur + 0.05);
    }
    let next = Date.now() + 7000;
    MGR._whisperHandle = setInterval(() => {
      if (Date.now() > next) { whisper(); next = Date.now() + (5000 + Math.random()*10000); }
    }, 500);

    MGR.layers.whispers = { gain, running: true,
      update: (lvl) => {
        const base = lvl < 7 ? 0.0 : lvl < 9 ? 0.55 : 0.85;
        gain.gain.cancelScheduledValues(ctx.currentTime);
        gain.gain.linearRampToValueAtTime(base, ctx.currentTime + 3);
      },
      teardown: () => clearInterval(MGR._whisperHandle),
    };
  }

  /* ---------- LAYER 4: HEARTBEAT ---------- */
  function setupHeartbeat() {
    const ctx = MGR.ctx;
    const gain = ctx.createGain();
    gain.gain.value = 0;
    gain.connect(MGR.musicGain);

    let intervalHandle = null;
    let currentBPM = 60;

    function thump() {
      const now = ctx.currentTime;
      // "lub" (low boom)
      const osc1 = ctx.createOscillator();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(90, now);
      osc1.frequency.exponentialRampToValueAtTime(42, now + 0.14);
      const g1 = ctx.createGain();
      g1.gain.setValueAtTime(0, now);
      g1.gain.linearRampToValueAtTime(0.7, now + 0.01);
      g1.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc1.connect(g1).connect(gain);
      osc1.start(now); osc1.stop(now + 0.2);

      // "dub" (higher, quick)
      const osc2 = ctx.createOscillator();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(110, now + 0.18);
      osc2.frequency.exponentialRampToValueAtTime(50, now + 0.32);
      const g2 = ctx.createGain();
      g2.gain.setValueAtTime(0, now + 0.18);
      g2.gain.linearRampToValueAtTime(0.48, now + 0.19);
      g2.gain.exponentialRampToValueAtTime(0.001, now + 0.34);
      osc2.connect(g2).connect(gain);
      osc2.start(now + 0.18); osc2.stop(now + 0.36);
    }

    function schedule() {
      if (intervalHandle) clearInterval(intervalHandle);
      // BPM scales with corruption level
      const lvl = C.level;
      const bpm = lvl < 7 ? 0 : lvl === 7 ? 70 : lvl === 8 ? 90 : lvl === 9 ? 110 : 130;
      currentBPM = bpm;
      if (bpm === 0) return;
      thump();
      const ms = 60000 / bpm;
      intervalHandle = setInterval(thump, ms);
    }

    MGR.layers.heartbeat = { gain, running: true,
      update: (lvl) => {
        const base = lvl < 7 ? 0.0 : lvl < 9 ? 0.6 : 0.85;
        gain.gain.cancelScheduledValues(ctx.currentTime);
        gain.gain.linearRampToValueAtTime(base, ctx.currentTime + 2);
        schedule();
      },
      teardown: () => { if (intervalHandle) clearInterval(intervalHandle); },
      get bpm() { return currentBPM; },
    };
  }

  /* ---------- SFX: one-shots ---------- */
  function stingReceptionist() {
    if (!MGR.unlocked) return;
    const ctx = MGR.ctx;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(660, now);
    osc.frequency.exponentialRampToValueAtTime(440, now + 0.12);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, now);
    g.gain.linearRampToValueAtTime(0.25, now + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.18);
    osc.connect(g).connect(MGR.sfxGain);
    osc.start(now); osc.stop(now + 0.2);
  }

  function stingClick() {
    if (!MGR.unlocked) return;
    const ctx = MGR.ctx;
    const now = ctx.currentTime;
    const lvl = C.level;
    // Thin click becomes hollow thump at high corruption
    const osc = ctx.createOscillator();
    osc.type = lvl < 4 ? 'sine' : 'triangle';
    const freq = lvl < 4 ? (520 + Math.random()*60) : (180 + Math.random()*60);
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.exponentialRampToValueAtTime(freq * 0.5, now + 0.05);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, now);
    g.gain.linearRampToValueAtTime(0.08 + lvl * 0.01, now + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.08);
    osc.connect(g).connect(MGR.sfxGain);
    osc.start(now); osc.stop(now + 0.1);
  }

  function stingDaredevil() {
    if (!MGR.unlocked) return;
    const ctx = MGR.ctx;
    const now = ctx.currentTime;
    // Big cartoon sting: drop + brass rasp
    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(800, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.45);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, now);
    g.gain.linearRampToValueAtTime(0.5, now + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.7);
    const filt = ctx.createBiquadFilter();
    filt.type = 'lowpass'; filt.frequency.value = 3000;
    osc.connect(filt).connect(g).connect(MGR.sfxGain);
    osc.start(now); osc.stop(now + 0.75);
  }

  function stingFinaleHeart() {
    if (!MGR.unlocked) return;
    const ctx = MGR.ctx;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(70, now);
    osc.frequency.exponentialRampToValueAtTime(25, now + 0.6);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, now);
    g.gain.linearRampToValueAtTime(0.95, now + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.9);
    const sub = ctx.createOscillator();
    sub.type = 'sine'; sub.frequency.value = 35;
    const sg = ctx.createGain();
    sg.gain.setValueAtTime(0, now);
    sg.gain.linearRampToValueAtTime(0.6, now + 0.02);
    sg.gain.exponentialRampToValueAtTime(0.0001, now + 0.9);
    sub.connect(sg).connect(MGR.sfxGain);
    osc.connect(g).connect(MGR.sfxGain);
    osc.start(now); osc.stop(now + 1);
    sub.start(now); sub.stop(now + 1);
  }

  function stingNurse() {
    if (!MGR.unlocked) return;
    const ctx = MGR.ctx;
    const now = ctx.currentTime;
    // Crackle + intercom buzz
    const noise = ctx.createBufferSource();
    noise.buffer = makeNoiseBuffer(0.4, 'white');
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0, now);
    ng.gain.linearRampToValueAtTime(0.35, now + 0.01);
    ng.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);
    const nf = ctx.createBiquadFilter();
    nf.type = 'bandpass'; nf.frequency.value = 2200; nf.Q.value = 3;
    noise.connect(nf).connect(ng).connect(MGR.sfxGain);
    noise.start(now); noise.stop(now + 0.4);
  }

  function silenceAll(durationMs) {
    // For finale: fade all layers to 0, then resume? (we don't resume — finale is the end.)
    const ctx = MGR.ctx;
    const now = ctx.currentTime;
    const dur = durationMs / 1000;
    MGR.musicGain.gain.cancelScheduledValues(now);
    MGR.musicGain.gain.setValueAtTime(MGR.musicGain.gain.value, now);
    MGR.musicGain.gain.linearRampToValueAtTime(0.0001, now + dur);
    MGR.sfxGain.gain.cancelScheduledValues(now);
    MGR.sfxGain.gain.setValueAtTime(MGR.sfxGain.gain.value, now);
    MGR.sfxGain.gain.linearRampToValueAtTime(0.0001, now + dur);
  }

  /* ---------- LIFECYCLE ---------- */
  function buildLayers() {
    setupHum();
    setupBeeps();
    setupSqueaks();
    setupWhispers();
    setupHeartbeat();
  }

  function applyLevelGain(lvl) {
    Object.values(MGR.layers).forEach(layer => {
      if (layer.update) layer.update(lvl);
    });
  }

  function unlock() {
    if (MGR.unlocked) return;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) { console.warn('[audio] No Web Audio support'); return; }
      MGR.ctx = new AC();
      MGR.masterGain = MGR.ctx.createGain();
      MGR.masterGain.gain.value = MGR.muted ? 0 : MGR.volume;
      MGR.masterGain.connect(MGR.ctx.destination);

      MGR.musicGain = MGR.ctx.createGain();
      MGR.musicGain.gain.value = 0.8;
      MGR.musicGain.connect(MGR.masterGain);

      MGR.sfxGain = MGR.ctx.createGain();
      MGR.sfxGain.gain.value = 1;
      MGR.sfxGain.connect(MGR.masterGain);

      buildLayers();
      applyLevelGain(C.level);
      MGR.unlocked = true;
      C.s.audioUnlocked = true;
      emitState();
    } catch (e) {
      console.error('[audio] unlock failed', e);
    }
  }

  function setVolume(v) {
    MGR.volume = Math.max(0, Math.min(1, v));
    C.s.volume = MGR.volume;
    if (MGR.masterGain && MGR.ctx) {
      MGR.masterGain.gain.cancelScheduledValues(MGR.ctx.currentTime);
      MGR.masterGain.gain.linearRampToValueAtTime(MGR.muted ? 0 : MGR.volume, MGR.ctx.currentTime + 0.1);
    }
  }

  function setMuted(m) {
    MGR.muted = !!m;
    C.s.audioMuted = MGR.muted;
    document.body.classList.toggle('muted', MGR.muted);
    if (MGR.masterGain && MGR.ctx) {
      MGR.masterGain.gain.cancelScheduledValues(MGR.ctx.currentTime);
      MGR.masterGain.gain.linearRampToValueAtTime(MGR.muted ? 0 : MGR.volume, MGR.ctx.currentTime + 0.1);
    }
  }

  function toggleMute() { setMuted(!MGR.muted); }

  function emitState() {
    C.emit('audio:state', {
      unlocked: MGR.unlocked,
      muted: MGR.muted,
      volume: MGR.volume,
      level: C.level,
    });
  }

  /* ---------- INIT ---------- */
  function init() {
    // First click anywhere unlocks audio (browser policy)
    const unlocker = () => { unlock(); window.removeEventListener('pointerdown', unlocker); window.removeEventListener('keydown', unlocker); };
    window.addEventListener('pointerdown', unlocker, { once: true });
    window.addEventListener('keydown', unlocker, { once: true });

    // React to corruption level changes
    C.on('corruption:level', ({ newLevel }) => {
      if (MGR.unlocked) applyLevelGain(newLevel);
    });
    C.on('corruption:click', () => { stingClick(); });
    C.on('corruption:reset', () => { applyLevelGain(0); });

    // Mute button hookup is in main.js; but we expose API and default state.
    document.body.classList.toggle('muted', MGR.muted);
  }

  window.addEventListener('DOMContentLoaded', init);

  /* ---------- EXPORT ---------- */
  window.AudioManager = {
    init, unlock,
    get unlocked() { return MGR.unlocked; },
    get muted() { return MGR.muted; },
    get volume() { return MGR.volume; },
    setVolume, setMuted, toggleMute,
    stingReceptionist, stingClick, stingDaredevil,
    stingFinaleHeart, stingNurse, silenceAll,
    _raw: MGR,
  };
})();
