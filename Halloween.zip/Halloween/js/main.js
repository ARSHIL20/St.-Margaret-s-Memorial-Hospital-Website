/* =================================================================
   main.js — UI CONTROLLER + CORRUPTION EFFECTS + GAMES
   -----------------------------------------------------------------
   Wire-up order (DOMContentLoaded):
     1. Navigation (hash + data-nav clicks)
     2. Global click → CorruptionState.recordClick
     3. Apply level-driven effects on `corruption:level`
     4. Features:
         - Footer clock
         - Sanity meter
         - Day / Night shift toggle (partial reset)
         - Shift label degradation
         - Hidden demo reset (R x 5)
         - Audio toast + mute/volume controls
         - Cursor trail canvas
         - Following eyes (paintings + chief of cardiology)
         - Testimonial rewrites
         - Typewriter word flicker
         - Gibberish text bursts
         - Fleeing buttons / cards
         - Nav rearrange
         - Mirror section
         - Corruption department dropdown options
         - Appointment form self-submit + finale
         - Ward 13 door reveal
         - Daredevil mode + red DO NOT PRESS button
         - Night Rounds mini-game
         - Nurse Station intercom
     5. Privacy Policy page (always sane)
     6. Mobile menu toggle
   ================================================================= */
(function () {
  'use strict';

  const C = window.CorruptionState;
  const A = window.AudioManager;
  const R = window.Receptionist;
  if (!C) throw new Error('main.js requires corruption.js');

  const prefersReduced = window.matchMedia &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ==========================================================
     1. NAVIGATION
     ========================================================== */
  const PAGE_IDS = ['home', 'departments', 'doctors', 'appointment', 'gallery', 'contact', 'ward13', 'privacy'];

  function showPage(id, opts = {}) {
    if (!PAGE_IDS.includes(id)) id = 'home';
    const sections = document.querySelectorAll('.page-section');
    sections.forEach(s => s.classList.toggle('active', s.id === id));
    document.querySelectorAll('.nav-link, [data-nav]').forEach(a => {
      a.classList.toggle('active', a.dataset.nav === id && a.closest('.primary-nav'));
    });
    window.scrollTo({ top: 0, behavior: prefersReduced ? 'auto' : 'smooth' });
    if (!opts.silent) {
      C.recordPage(id);
      updateFooterClock();
    }
    // Ward13 special reaction
    if (id === 'ward13' && !C.s._reactedToWard13) {
      C.s._reactedToWard13 = true;
      C.recordInteraction(5);
      R && R.say && R.say('ward13');
    }
    // Close mobile menu
    document.getElementById('primary-nav')?.classList.remove('open');
    document.getElementById('mobile-menu-btn')?.setAttribute('aria-expanded', 'false');
  }

  function parseHash() {
    const h = (location.hash || '#home').slice(1).toLowerCase();
    return PAGE_IDS.includes(h) ? h : 'home';
  }

  function setupNav() {
    // Data-nav links
    document.addEventListener('click', e => {
      const a = e.target.closest('[data-nav]');
      if (!a) return;
      e.preventDefault();
      const id = a.dataset.nav;
      location.hash = '#' + id;
      showPage(id);
    });
    window.addEventListener('hashchange', () => showPage(parseHash()));
    // Initial page
    showPage(parseHash(), { silent: true });
    // Record home page at least once for clock
    if (!C.s.pagesVisited.has('home')) C.recordPage('home');
  }

  /* ==========================================================
     2. GLOBAL CLICK → CORRUPTION
     ========================================================== */
  function setupClickCatcher() {
    document.addEventListener('pointerdown', e => {
      if (e.target.closest('.sanity-meter') || e.target.closest('#cursor-canvas')) return;
      C.recordClick(e.target);
    }, true); // capture so we count *first*

    // Also track hovers on interesting elements
    document.addEventListener('pointerover', e => {
      const interesting = e.target.closest('#gallery, #appoint-form, [data-doctor], #ward13-door, .btn--primary');
      if (interesting) {
        let id = interesting.id || interesting.className || 'el';
        id = id.toString().slice(0, 24);
        C.recordHover(interesting, id);
      }
    }, true);
  }

  /* ==========================================================
     3. CORRUPTION LEVEL EFFECTS DRIVER
     ========================================================== */
  function applyBodyLevel(lvl) {
    document.body.classList.remove('corruption-0','corruption-1','corruption-2','corruption-3','corruption-4','corruption-5','corruption-6','corruption-7','corruption-8','corruption-9','corruption-10');
    document.body.classList.add('corruption-' + lvl);
  }

  function updateSanityMeter(lvl) {
    const fill = document.getElementById('sanity-fill');
    const label = document.getElementById('sanity-label');
    const pct = Math.min(100, (lvl / C.maxLevel) * 100);
    if (fill) fill.style.width = pct + '%';
    if (label) {
      const sanity = Math.max(0, Math.round(100 - pct));
      label.textContent = `PATIENT SANITY: ${sanity}%`;
    }
  }

  function updateFooterClock() {
    const el = document.getElementById('footer-clock');
    if (!el) return;
    const h = C.s.footerHour;
    const m = C.s.footerMinutes;
    const mm = String(m).padStart(2, '0');
    el.textContent = `${h}:${mm} PM`;
  }

  /* ------- testimonial rewrites L3+ ------- */
  const TESTIMONIAL_REPLACEMENTS = [
    ["Great service!", "It won't let us leave."],
    ["treated us like family", "treated us like inventory"],
    ["Three generations", "Three generations. None left."],
    ["ran like clockwork", "ran. still runs. won't stop running."],
    ["saved my husband's life", "kept my husband. we don't know in what condition."],
    ["Every detail was covered", "Every detail was written down. In a book with no last page."],
    ["You rarely see that level of coordination", "You rarely see them leave. They rarely see the exit."],
  ];

  function rewriteTestimonials(force = false) {
    if (C.level < 3 && !force) return;
    document.querySelectorAll('.testi-card p').forEach((p) => {
      const orig = p._orig || p.textContent;
      p._orig = orig;
      const prob = C.level < 4 ? 0.25 : C.level < 6 ? 0.6 : 1.0;
      if (force || Math.random() < prob) {
        for (const [from, to] of TESTIMONIAL_REPLACEMENTS) {
          if (orig.includes(from) || force) {
            p.textContent = to;
            return;
          }
        }
        // Generic rewrite
        const generic = C.level < 6
          ? "The doctors were kind. The walls were kinder."
          : C.level < 8
          ? "I came in for a checkup. I leave never."
          : "Everything is fine. I am fine. The walls are fine.";
        p.textContent = generic;
      }
    });
  }

  /* ------- random typewriter flicker L1-2+ ------- */
  const FLICKER_WORDS_L1 = ['excellent', 'clean', 'professional', 'compassionate', 'safe', 'friendly'];
  const FLICKER_WORDS_L3 = ['leave', 'exit', 'discharge', 'cured', 'home', 'family'];

  function flickerWords() {
    const lvl = C.level;
    if (lvl < 1) return;
    const words = lvl < 3 ? FLICKER_WORDS_L1 : FLICKER_WORDS_L3;
    const textNodes = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    let node;
    while ((node = walker.nextNode())) {
      const txt = node.nodeValue || '';
      if (txt.length < 30 || txt.length > 300) continue;
      if (node.parentElement.closest('.sanity-meter, .receptionist, .finale, .privacy-paper, .ward13, #site-footer')) continue;
      for (const w of words) {
        const re = new RegExp(`\\b${w}\\b`, 'i');
        if (re.test(txt)) { textNodes.push({ node, w }); break; }
      }
    }
    if (!textNodes.length) return;
    const pick = textNodes[Math.floor(Math.random() * textNodes.length)];
    const parent = pick.node.parentElement;
    if (parent._flickering) return;
    parent._flickering = true;
    parent.classList.add('type-flicker');
    setTimeout(() => {
      parent.classList.remove('type-flicker');
      parent._flickering = false;
    }, 2600);
  }

  /* ------- Gibberish text bursts L7+ ------- */
  const GIBBERISH_CHARS = '!@#$%^&*()_+{}|:"<>?~`[]\\;\',./▓▒░█╬╩╦╠╣║╗╔▀▄■';
  function gibberishBurst() {
    if (C.level < 7) return;
    const paras = document.querySelectorAll('main p, main h1, main h2, main h3, main label');
    if (!paras.length) return;
    const el = paras[Math.floor(Math.random() * paras.length)];
    if (el.closest('.privacy-paper, .ward13')) return;
    const orig = el.textContent;
    el.classList.add('gibberish');
    let t = 0;
    const iv = setInterval(() => {
      const arr = [...orig];
      for (let i = 0; i < arr.length; i++) {
        if (Math.random() < 0.4) arr[i] = GIBBERISH_CHARS[Math.floor(Math.random() * GIBBERISH_CHARS.length)];
      }
      el.textContent = arr.join('');
      t++;
      if (t > 6) {
        clearInterval(iv);
        el.textContent = orig;
        el.classList.remove('gibberish');
      }
    }, 70);
  }

  /* ------- Random horror word replacement L8+ ------- */
  const HORROR_PAIRS = [
    ['doctors', 'caretakers'],
    ['nurses', 'attendants'],
    ['family', 'next of kin'],
    ['medicine', 'treatment'],
    ['healing', 'processing'],
    ['visitors', 'the others'],
    ['rooms', 'compartments'],
  ];
  function swapHorrorWords() {
    if (C.level < 8) return;
    const paras = document.querySelectorAll('main p, main h2, main h3');
    const pick = paras[Math.floor(Math.random() * paras.length)];
    if (!pick || pick.closest('.privacy-paper, .ward13')) return;
    for (const [from, to] of HORROR_PAIRS) {
      const re = new RegExp(`\\b${from}\\b`, 'i');
      if (re.test(pick.innerHTML) && !pick.innerHTML.includes('horror-word')) {
        pick.innerHTML = pick.innerHTML.replace(re, `<span class="horror-word">${to}</span>`);
        return;
      }
    }
  }

  /* ------- Button shivers L5+ ------- */
  function maybeShiver(e) {
    if (C.level < 5) return;
    const btn = e.target.closest('.btn, .icon-btn, button');
    if (!btn) return;
    const chance = C.level < 6 ? 0.08 : C.level < 8 ? 0.18 : 0.28;
    if (Math.random() < chance) {
      btn.classList.add('shiver');
      setTimeout(() => btn.classList.remove('shiver'), 750);
    }
    // Deadpan tooltips L5+ on primary buttons
    if (C.level >= 5 && btn.classList.contains('btn--primary')) {
      if (!btn.dataset.tooltip && Math.random() < 0.25) {
        const tips = [
          "This button does nothing. You clicked it anyway. Classic horror movie behavior.",
          "We saved this click in your file.",
          "That does not go where you think it goes.",
        ];
        btn.dataset.tooltip = tips[Math.floor(Math.random()*tips.length)];
      }
    }
  }

  /* ------- Fleeing buttons / cards L7+ ------- */
  function setupFleeing() {
    document.addEventListener('pointermove', (e) => {
      if (C.level < 7) return;
      const targets = document.querySelectorAll('.btn:not(.fleeing), .dept-card:not(.fleeing), .feature-card:not(.fleeing)');
      targets.forEach(t => {
        const r = t.getBoundingClientRect();
        const cx = r.left + r.width / 2;
        const cy = r.top + r.height / 2;
        const dx = e.clientX - cx;
        const dy = e.clientY - cy;
        const dist = Math.hypot(dx, dy);
        if (dist < 110) {
          t.classList.add('fleeing');
          const ang = Math.atan2(dy, dx);
          const push = 160 - dist;
          const tx = -Math.cos(ang) * push * 0.8;
          const ty = -Math.sin(ang) * push * 0.8;
          t.style.transform = `translate(${tx}px, ${ty}px) rotate(${tx * 0.05}deg)`;
          setTimeout(() => {
            t.style.transform = '';
            t.classList.remove('fleeing');
          }, 900 + Math.random() * 900);
        }
      });
    }, { passive: true });
  }

  /* ------- Nav item rearrange L7+ ------- */
  let navScrambled = false;
  function maybeScrambleNav() {
    if (C.level < 7 || navScrambled) return;
    if (Math.random() > 0.25) return;
    navScrambled = true;
    const ul = document.querySelector('.primary-nav ul');
    if (!ul) return;
    const items = Array.from(ul.children);
    for (let i = items.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      ul.insertBefore(items[j], items[i]);
    }
    // Re-label occasionally
    items.forEach(li => {
      const a = li.querySelector('a');
      if (!a) return;
      if (Math.random() < 0.2) {
        a.textContent = a.textContent.split('').sort(() => Math.random() - 0.5).join('');
      }
    });
  }

  /* ------- Mirror section L8+ ------- */
  function addMirror() {
    if (C.level < 8 || C.s.flags.mirrorAdded || document.querySelector('.mirror-section')) return;
    C.s.flags.mirrorAdded = true;
    const m = document.createElement('div');
    m.className = 'mirror-section';
    const inner = document.createElement('div');
    inner.className = 'mirror-inner';
    m.appendChild(inner);
    document.body.appendChild(m);
    // Mirror contents: clone main but delay rendering by animating opacity shifts
    function tickMirror() {
      const main = document.querySelector('main') || document.body;
      try {
        const snapshot = main.innerText.slice(0, 400);
        inner.textContent = snapshot;
      } catch {}
    }
    setInterval(tickMirror, 2000);
    setTimeout(() => m.classList.add('on'), 500);
  }

  /* ------- Department dropdown corruption L5+ ------- */
  const EXTRA_DEPTS = [
    { value: 'basement', label: 'The Basement' },
    { value: 'ward13',   label: 'Ward 13 — Do Not Visit' },
    { value: 'morgue',   label: 'Morgue (temporarily unstaffed)' },
  ];
  function applyDepartmentDropdown() {
    if (C.level < 5) return;
    const sel = document.getElementById('f-dept');
    if (!sel || sel.dataset.corrupted) return;
    sel.dataset.corrupted = '1';
    EXTRA_DEPTS.forEach(o => {
      const opt = document.createElement('option');
      opt.value = o.value;
      opt.textContent = o.label;
      sel.appendChild(opt);
    });
  }

  /* ------- Staff photo swap to "night staff" L9+ ------- */
  const NIGHT_STAFF = [
    { initials: '???', color: '#111', text: '#4a0e0e', name: 'Dr. —— ————', role: 'On leave. Present anyway.', bio: '"..."' },
    { initials: 'MUT', color: '#1a0a0a', text: '#7a1515', name: 'Nurse Mute', role: 'Speaks in chart annotations only.', bio: '"."' },
    { initials: '14',  color: '#0a0a0a', text: '#333',    name: 'Orderly Fourteen', role: 'Facilities. Audio.', bio: '"You don\'t call us. We call you."' },
    { initials: 'HOL', color: '#0f0f1f', text: '#555',    name: 'Dr. Holloway (retired)', role: '1942–1978. Still head of cardiology.', bio: '"Listening is the first test I order."' },
    { initials: 'EYE', color: '#111',    text: '#fff',    name: 'The Eyes in the Donor Wall', role: 'Adjunct, observational.', bio: '"We see everything. We miss very little."' },
    { initials: '???', color: '#220000', text: '#900',    name: 'Dr. Krane', role: 'Nightshift attending. MD? PhD?', bio: '"Trust the process. The process trusts nothing."' },
  ];
  function swapToNightStaff() {
    if (C.level < 9) return;
    const cards = document.querySelectorAll('.doctor-card');
    cards.forEach((card, i) => {
      const photo = card.querySelector('.doctor-photo');
      const name = card.querySelector('h3');
      const role = card.querySelector('.doctor-role');
      const bio = card.querySelector('.doctor-body p');
      const init = card.querySelector('.doc-initials');
      if (card.dataset.swapped) return;
      const n = NIGHT_STAFF[i % NIGHT_STAFF.length];
      if (photo) photo.style.background = `linear-gradient(135deg, ${n.color}, #000)`;
      if (init) { init.textContent = n.initials; init.style.color = n.text; }
      if (name) name.textContent = n.name;
      if (role) role.textContent = n.role;
      if (bio) bio.textContent = n.bio;
      card.dataset.swapped = '1';
    });
  }

  /* ------- Appointment form self-submit + finale at L10 ------- */
  function setupAppointmentForm() {
    const form = document.getElementById('appoint-form');
    if (!form) return;
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      if (C.level < 10) {
        // Partial success
        R && R.say && R.say('user_chat_default');
        // Show small confirmation then revert
        form.querySelectorAll('input, select, textarea, button').forEach(x => x.disabled = true);
        const btn = document.getElementById('submit-appoint');
        if (btn) btn.textContent = 'Request sent…';
        setTimeout(() => {
          form.querySelectorAll('input, select, textarea, button').forEach(x => x.disabled = false);
          if (btn) btn.textContent = 'Request Appointment';
        }, 2000);
      } else {
        triggerFinale();
      }
    });
  }

  function autoSubmitAtLevel10() {
    if (C.level < 10 || C.s.flags.appointmentSubmitted) return;
    C.s.flags.appointmentSubmitted = true;
    const form = document.getElementById('appoint-form');
    const confirmed = document.getElementById('appoint-confirmed');
    if (form) form.hidden = true;
    if (confirmed) confirmed.hidden = false;
    // Go to appointment page if not there
    if (!document.getElementById('appointment').classList.contains('active')) {
      location.hash = '#appointment';
      showPage('appointment');
    }
    setTimeout(() => triggerFinale(), 3200);
  }

  function triggerFinale() {
    if (C.s.flags.finalePlayed) return;
    C.s.flags.finalePlayed = true;
    const finale = document.getElementById('finale');
    const silence = document.getElementById('finale-silence');
    const heart = document.getElementById('finale-heart');
    const never = document.getElementById('finale-never');
    if (!finale) return;
    finale.hidden = false;
    finale.removeAttribute('aria-hidden');
    // Silence
    A && A.silenceAll && A.silenceAll(2800);
    // 3 seconds silence → heartbeat → never
    let t = 0;
    const tick = setInterval(() => {
      t += 100;
      if (t === 3000) {
        finale.classList.add('finale-beat');
        A && A.stingFinaleHeart && A.stingFinaleHeart();
      }
      if (t === 3800) {
        // Black screen then text
        silence.style.background = '#000';
        heart.style.opacity = 0;
      }
      if (t === 4200) {
        finale.classList.add('finale-never-on');
        clearInterval(tick);
      }
    }, 100);
  }

  /* ==========================================================
     4. WARD 13 DOOR REVEAL
     ========================================================== */
  function revealWard13() {
    if (C.level < 6 || C.s.flags.ward13Revealed) return;
    C.s.flags.ward13Revealed = true;
    const door = document.getElementById('ward13-door');
    if (door) door.hidden = false;
  }

  /* ==========================================================
     5. DAY / NIGHT SHIFT TOGGLE
     ========================================================== */
  function degradeShiftLabel() {
    const label = document.getElementById('shift-label');
    if (!label) return;
    const lvl = C.level;
    const stages = [
      { min: 0, text: 'Day Shift' },
      { min: 4, text: 'Day Shif_t' },
      { min: 6, text: 'Day  hif_' },
      { min: 8, text: 'why would you leave' },
      { min: 10,text: 'you cannot leave' },
    ];
    for (let i = stages.length - 1; i >= 0; i--) {
      if (lvl >= stages[i].min) {
        if (label.textContent !== stages[i].text) label.textContent = stages[i].text;
        break;
      }
    }
  }
  function setupShiftToggle() {
    const cb = document.getElementById('shift-checkbox');
    if (!cb) return;
    cb.addEventListener('change', () => {
      const night = cb.checked;
      document.body.classList.toggle('night-shift', night);
      C.s.nightShift = night;
      // Heavier ambience when Night Shift toggled on (audio already reacts to level but we nudge)
      if (night) {
        C.recordInteraction(0.8);
      }
    });
  }

  /* ==========================================================
     6. DEMO RESET — press R 5x
     ========================================================== */
  function setupReset() {
    let count = 0, last = 0;
    window.addEventListener('keydown', (e) => {
      // Ignore if user is typing in input
      if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable)) return;
      const now = Date.now();
      if ((e.key === 'r' || e.key === 'R') && now - last < 1400) {
        count++;
        if (count >= 4) {
          resetEverything();
          count = 0;
        }
      } else {
        count = (e.key === 'r' || e.key === 'R') ? 1 : 0;
      }
      last = now;
    });
  }
  function resetEverything() {
    const finale = document.getElementById('finale');
    if (finale) { finale.hidden = true; finale.classList.remove('finale-beat', 'finale-never-on'); finale.setAttribute('aria-hidden','true'); }
    const form = document.getElementById('appoint-form');
    const confirmed = document.getElementById('appoint-confirmed');
    if (form) form.hidden = false;
    if (confirmed) confirmed.hidden = true;
    // Remove corrupted dept options + swapback doctor cards
    const sel = document.getElementById('f-dept');
    if (sel) {
      delete sel.dataset.corrupted;
      [...sel.querySelectorAll('option')].forEach(opt => {
        if (['basement','ward13','morgue'].includes(opt.value)) opt.remove();
      });
    }
    document.querySelectorAll('.doctor-card').forEach(c => delete c.dataset.swapped);
    document.querySelectorAll('.dept-card, .feature-card').forEach(c => c.style.transform = '');
    // Refresh page from cache actually? Cheaper: re-run level 0
    C.reset();
    location.hash = '#home';
    showPage('home');
    // Reload styles: reset body classes
    document.body.className = 'corruption-0';
    if (C.s.nightShift) document.body.classList.add('night-shift');
    // Remove mirror + horror-word spans
    document.querySelectorAll('.mirror-section').forEach(m => m.remove());
    document.querySelectorAll('.horror-word').forEach(h => {
      const t = h.textContent;
      h.replaceWith(t);
    });
    // Remove ward13 door
    const door = document.getElementById('ward13-door');
    if (door) door.hidden = true;
    // Hide night rounds / nurse
    document.getElementById('night-rounds').hidden = true;
    document.getElementById('nurse-station-wrap').hidden = true;
    // Reset testimonials
    document.querySelectorAll('.testi-card p').forEach(p => { if (p._orig) p.textContent = p._orig; });
    navScrambled = false;
    // Reset sanity meter
    updateSanityMeter(0);
  }

  /* ==========================================================
     7. AUDIO UI: toast + mute + volume
     ========================================================== */
  function setupAudioUI() {
    const toast = document.getElementById('audio-toast');
    const closeToast = document.getElementById('toast-close');
    if (toast) {
      setTimeout(() => toast.classList.add('show'), 1200);
      const dismiss = () => toast.classList.remove('show');
      closeToast && closeToast.addEventListener('click', dismiss);
      setTimeout(dismiss, 10000);
    }
    const muteBtn = document.getElementById('mute-btn');
    const vol = document.getElementById('volume-slider');
    if (muteBtn) {
      muteBtn.addEventListener('click', () => {
        A && A.toggleMute();
        muteBtn.setAttribute('aria-pressed', String(A ? A.muted : false));
      });
    }
    if (vol) {
      vol.value = String(Math.round((C.s.volume || 0.6) * 100));
      vol.addEventListener('input', () => {
        const v = Number(vol.value) / 100;
        A && A.setVolume(v);
      });
    }
  }

  /* ==========================================================
     8. CURSOR TRAIL CANVAS
     ========================================================== */
  const CURSOR = {
    canvas: null, ctx: null, points: [], lastX: 0, lastY: 0,
    stampDebounce: 0,
  };
  function setupCursor() {
    if (prefersReduced) return;
    const c = document.getElementById('cursor-canvas');
    if (!c) return;
    CURSOR.canvas = c;
    CURSOR.ctx = c.getContext('2d');
    resizeCursor();
    window.addEventListener('resize', resizeCursor);
    window.addEventListener('pointermove', handleCursorMove, { passive: true });
    requestAnimationFrame(cursorFrame);
  }
  function resizeCursor() {
    const c = CURSOR.canvas; if (!c) return;
    c.width = window.innerWidth;
    c.height = window.innerHeight;
  }
  function handleCursorMove(e) {
    CURSOR.lastX = e.clientX; CURSOR.lastY = e.clientY;
    document.body.classList.toggle('cursor-trail', C.level >= 3);
    if (C.level < 3) { CURSOR.points.length = 0; return; }
    CURSOR.points.push({ x: e.clientX, y: e.clientY, t: Date.now(), vx: e.movementX || 0, vy: e.movementY || 0 });
    const MAX = C.level < 6 ? 40 : 70;
    while (CURSOR.points.length > MAX) CURSOR.points.shift();

    // Occasional URGENT stamp L6+
    if (C.level >= 6 && Date.now() - CURSOR.stampDebounce > 6000 && Math.random() < 0.01) {
      CURSOR.stampDebounce = Date.now();
      stampUrgent(e.clientX, e.clientY);
    }
  }
  function stampUrgent(x, y) {
    const ctx = CURSOR.ctx;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(-0.1 + Math.random() * 0.2);
    ctx.font = 'bold 18px Inter, sans-serif';
    ctx.fillStyle = 'rgba(185,28,28,0.55)';
    ctx.strokeStyle = 'rgba(185,28,28,0.55)';
    ctx.lineWidth = 2;
    const text = 'URGENT';
    const w = ctx.measureText(text).width + 20;
    ctx.strokeRect(-w / 2, -14, w, 28);
    ctx.fillText(text, -w / 2 + 10, 6);
    ctx.restore();
  }
  function cursorFrame() {
    const ctx = CURSOR.ctx; const c = CURSOR.canvas;
    if (!ctx || !c) { requestAnimationFrame(cursorFrame); return; }
    ctx.clearRect(0, 0, c.width, c.height);
    if (C.level >= 3 && !prefersReduced) {
      const now = Date.now();
      for (let i = 0; i < CURSOR.points.length; i++) {
        const p = CURSOR.points[i];
        const age = (now - p.t) / 900;
        if (age > 1) continue;
        const a = (1 - age) * (C.level < 5 ? 0.18 : C.level < 8 ? 0.28 : 0.4);
        ctx.beginPath();
        ctx.fillStyle = `rgba(180,180,180,${a})`;
        const r = 1.2 + i * 0.05;
        ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
        ctx.fill();
        // Dust particles (speckle)
        if (C.level >= 5 && i % 4 === 0) {
          ctx.fillStyle = `rgba(255,255,255,${a * 0.7})`;
          ctx.fillRect(p.x + (Math.random() - .5) * 6, p.y + (Math.random() - .5) * 6, 1, 1);
        }
      }
    }
    requestAnimationFrame(cursorFrame);
  }

  /* ==========================================================
     9. FOLLOWING EYES (paintings + doctor)
     ========================================================== */
  function setupEyes() {
    let mouseX = window.innerWidth / 2, mouseY = window.innerHeight / 2;
    window.addEventListener('pointermove', e => { mouseX = e.clientX; mouseY = e.clientY; }, { passive: true });
    function tick() {
      document.querySelectorAll('.eye .pupil').forEach(p => {
        const eye = p.parentElement;
        if (!eye) return;
        const r = eye.getBoundingClientRect();
        if (r.width === 0 || r.height === 0) return;
        const cx = r.left + r.width / 2;
        const cy = r.top + r.height / 2;
        const dx = mouseX - cx, dy = mouseY - cy;
        const ang = Math.atan2(dy, dx);
        const maxR = 7;
        const px = Math.cos(ang) * maxR;
        const py = Math.sin(ang) * maxR;
        p.style.transform = `translate(calc(-50% + ${px}px), calc(-50% + ${py}px))`;
      });
      requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  /* ==========================================================
     10. CORRUPTION TICK (periodic visual effects)
     ========================================================== */
  function corruptionTick() {
    const lvl = C.level;
    // flicker words every few seconds L1+
    flickerWords();
    // testimonial rewrite chance
    if (Math.random() < 0.06) rewriteTestimonials(false);
    // gibberish bursts L7+
    if (lvl >= 7 && Math.random() < (lvl === 10 ? 0.12 : 0.05)) gibberishBurst();
    // Horror word swaps L8+
    if (lvl >= 8 && Math.random() < 0.04) swapHorrorWords();
    // Nav scramble chance L7+
    maybeScrambleNav();
    // Screen shake L7+
    maybeScreenShake();
  }
  let shakeSeed = 0;
  function maybeScreenShake() {
    if (prefersReduced) return;
    const lvl = C.level;
    if (lvl < 7) return;
    const amount = Math.min(10, (lvl - 6) * 1.8);
    const wrap = document.getElementById('shake-wrapper');
    if (!wrap) return;
    shakeSeed += 0.02 * (lvl - 6);
    const x = (Math.sin(shakeSeed * 4.3) * amount);
    const y = (Math.cos(shakeSeed * 3.1) * amount);
    wrap.style.transform = `translate(${x.toFixed(2)}px, ${y.toFixed(2)}px)`;
  }

  /* ==========================================================
     11. NIGHT ROUNDS MINI-GAME
     ========================================================== */
  const GAME = {
    running: false, score: 0, timeLeft: 30, iv: null, spawnIv: null,
  };
  function setupNightRounds() {
    const wrap = document.getElementById('night-rounds');
    const start = document.getElementById('nr-start');
    if (!wrap || !start) return;
    start.addEventListener('click', () => {
      if (GAME.running) return;
      runNightRounds();
    });
  }
  function maybeShowNightRounds() {
    if (C.level < 4 || C.s.flags.nightRoundsShown) return;
    C.s.flags.nightRoundsShown = true;
    const el = document.getElementById('night-rounds');
    if (el) el.hidden = false;
    R && R.say && R.say('night_rounds_intro');
    const n = document.getElementById('nurse-station-wrap');
    if (n) n.hidden = false;
    C.s.flags.nurseStationShown = true;
  }
  function runNightRounds() {
    const arena = document.getElementById('nr-arena');
    const scoreEl = document.getElementById('nr-score');
    const timerEl = document.getElementById('nr-timer');
    const resultEl = document.getElementById('nr-result');
    if (!arena) return;
    arena.innerHTML = '';
    GAME.running = true; GAME.score = 0; GAME.timeLeft = 30;
    scoreEl.textContent = '0'; timerEl.textContent = '30'; resultEl.textContent = '';

    GAME.spawnIv = setInterval(() => spawnTarget(arena), Math.max(380, 900 - C.level * 50));
    GAME.iv = setInterval(() => {
      GAME.timeLeft--;
      timerEl.textContent = String(GAME.timeLeft);
      if (GAME.timeLeft <= 0) endNightRounds();
    }, 1000);
  }
  function spawnTarget(arena) {
    const r = arena.getBoundingClientRect();
    const t = document.createElement('div');
    const shadow = Math.random() < (0.35 + C.level * 0.03);
    t.className = 'nr-target' + (shadow ? ' nr-shadow' : '');
    const size = 46;
    const x = Math.random() * (r.width - size);
    const y = Math.random() * (r.height - size);
    t.style.left = x + 'px';
    t.style.top = y + 'px';
    const life = Math.max(700, 2000 - C.level * 120);
    let dead = false;
    const kill = () => {
      if (dead) return;
      dead = true;
      t.remove();
    };
    t.addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      if (dead) return;
      dead = true;
      GAME.score += shadow ? 3 : 1;
      document.getElementById('nr-score').textContent = String(GAME.score);
      t.style.transform = 'scale(1.5)';
      t.style.opacity = '0';
      setTimeout(() => t.remove(), 180);
    });
    setTimeout(kill, life);
    arena.appendChild(t);
  }
  function endNightRounds() {
    GAME.running = false;
    clearInterval(GAME.iv);
    clearInterval(GAME.spawnIv);
    document.querySelectorAll('.nr-target').forEach(t => t.remove());
    const result = document.getElementById('nr-result');
    if (!result) return;
    const lvl = C.level;
    C.s._lastGameScore = GAME.score;
    if (GAME.score >= 12) {
      result.textContent = 'Ward Clerk commendation — excellent rounds.';
    } else if (GAME.score >= 6) {
      result.textContent = 'Adequate. Report to the linen closet for debrief.';
    } else {
      result.textContent = 'Poor performance. You heard the gurney coming.';
    }
    if (lvl >= 8) {
      const extras = [
        ' (The ones that got away will remember you.)',
        ' (One of them waved goodbye.)',
        ' (Try not to think about the ones that were not targets.)',
      ];
      result.textContent += extras[Math.floor(Math.random()*extras.length)];
    }
    R && R.say && R.say('night_rounds_win');
  }

  /* ==========================================================
     12. NURSE STATION
     ========================================================== */
  const NURSE_MESSAGES = [
    "The nurse station advises… do not take the elevator. It only goes down.",
    "Reminder: If you hear your name from a room you didn't visit, do not answer.",
    "Tonight's soup is tomato. Tomorrow's soup is also tomato. The tomato is watching.",
    "Code lavender is in effect on all floors. Code lavender is not a real code.",
    "Please remember to sign the visitor's log. Failure to sign will be interpreted as never having left.",
    "The fire alarm you just imagined was not your imagination. Please remain calm.",
    "Staff announcement: Dr. Krane's scissors have returned themselves. No further questions.",
    "The third stall in the east wing restroom is currently occupied. It has been occupied since 1974.",
  ];
  function setupNurseStation() {
    const btn = document.getElementById('nurse-btn');
    if (!btn) return;
    btn.addEventListener('click', () => {
      A && A.stingNurse && A.stingNurse();
      const msg = NURSE_MESSAGES[Math.floor(Math.random() * NURSE_MESSAGES.length)];
      showIntercom(msg);
      C.recordInteraction(0.6);
    });
  }
  function showIntercom(msg) {
    const overlay = document.createElement('div');
    overlay.className = 'intercom-overlay';
    overlay.innerHTML = `
      <div class="intercom-box">
        <div class="intercom-grille" aria-hidden="true"></div>
        <h3>📞 NURSE STATION</h3>
        <p class="intercom-msg"></p>
      </div>`;
    overlay.querySelector('.intercom-msg').textContent = msg;
    document.body.appendChild(overlay);
    setTimeout(() => { overlay.style.opacity = '0'; overlay.style.transition = 'opacity .6s'; }, 3400);
    setTimeout(() => overlay.remove(), 4100);
  }

  /* ==========================================================
     13. DAREDEVIL MODE — big red DO NOT PRESS
     ========================================================== */
  function setupDaredevil() {
    const wrap = document.getElementById('daredevil-wrap');
    const btn = document.getElementById('daredevil-btn');
    const toggle = document.getElementById('daredevil-toggle');
    if (!wrap) return;
    // Reveal at corruption 3+
    const reveal = () => { if (C.level >= 3) wrap.hidden = false; };
    C.on('corruption:level', reveal);
    reveal();

    let on = false;
    toggle && toggle.addEventListener('click', () => {
      on = !on;
      C.s.daredevil = on;
      toggle.textContent = 'Daredevil: ' + (on ? 'ON' : 'OFF');
      toggle.classList.toggle('on', on);
      if (btn) btn.disabled = !on;
    });

    btn && btn.addEventListener('click', () => {
      if (!on) return;
      C.s.flags.daredevilTriggered = true;
      // Cartoon jumpscare face
      const face = document.createElement('div');
      face.className = 'js-face';
      document.body.appendChild(face);
      A && A.stingDaredevil && A.stingDaredevil();
      setTimeout(() => face.remove(), 950);
      C.recordInteraction(2);
      R && R.say && setTimeout(() => R.say('daredevil'), 1000);
    });
  }

  /* ==========================================================
     14. PRIVACY POLICY (always sane)
     ========================================================== */
  function setupPrivacyLinks() {
    document.querySelectorAll('#privacy-link, #privacy-link-inline').forEach(a => {
      a.addEventListener('click', (e) => {
        e.preventDefault();
        location.hash = '#privacy';
        showPage('privacy');
      });
    });
  }

  /* ==========================================================
     15. MOBILE MENU
     ========================================================== */
  function setupMobile() {
    const btn = document.getElementById('mobile-menu-btn');
    const nav = document.getElementById('primary-nav');
    if (!btn || !nav) return;
    btn.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', String(open));
    });
  }

  /* ==========================================================
     16. HEADER AUTO-HIDE (on scroll-down, show on scroll-up)
     ========================================================== */
  function setupHeaderAutoHide() {
    const header = document.getElementById('site-header');
    if (!header) return;

    if (prefersReduced) { header.classList.add('is-autohide-disabled'); return; }

    const HIDE_DELTA = 24;      // px of downward scroll to trigger hide
    const SHOW_DELTA = 12;      // px of upward scroll to trigger show
    const TOP_PAD = 16;         // always show within this distance from top
    const MAX_HIDE_AT = 220;    // only auto-hide after scrolled past this
    const THROTTLE_MS = 14;

    let lastY = window.scrollY || window.pageYOffset || 0;
    let ticking = false;
    let rafId = null;
    let lastUpdate = 0;

    function apply() {
      ticking = false;
      const nowY = window.scrollY || window.pageYOffset || 0;
      const delta = nowY - lastY;
      const at = performance.now();

      // Always show near top
      if (nowY <= TOP_PAD) {
        header.classList.remove('is-hidden');
        lastY = nowY;
        return;
      }

      // Below a minimal threshold, ignore jitter
      if (nowY < MAX_HIDE_AT) {
        if (nowY < lastY) header.classList.remove('is-hidden');
        lastY = nowY;
        return;
      }

      if (delta > HIDE_DELTA) {
        header.classList.add('is-hidden');
        lastY = nowY;
      } else if (delta < -SHOW_DELTA) {
        header.classList.remove('is-hidden');
        lastY = nowY;
      }

      lastUpdate = at;
    }

    function onScroll() {
      if (ticking) return;
      const at = performance.now();
      if (at - lastUpdate < THROTTLE_MS && rafId) return;
      ticking = true;
      rafId = requestAnimationFrame(apply);
    }

    // Force-show when user interacts with header itself (menu open, focus, etc.)
    const show = () => header.classList.remove('is-hidden');
    header.addEventListener('mouseenter', show, { passive: true });
    header.addEventListener('focusin', show, true);
    header.addEventListener('touchstart', show, { passive: true });

    // Also show immediately if any mobile nav open state toggled or search focused
    const mobileBtn = document.getElementById('mobile-menu-btn');
    if (mobileBtn) mobileBtn.addEventListener('click', show);

    window.addEventListener('scroll', onScroll, { passive: true });
    // Safety: show if user alt-tabs or resizes
    window.addEventListener('resize', show, { passive: true });
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') show();
    });
  }

  /* ==========================================================
     CORRUPTION LEVEL REACTOR
     ========================================================== */
  function onLevelChange({ oldLevel, newLevel }) {
    applyBodyLevel(newLevel);
    updateSanityMeter(newLevel);
    degradeShiftLabel();
    rewriteTestimonials(true);
    applyDepartmentDropdown();
    revealWard13();
    swapToNightStaff();
    maybeShowNightRounds();
    addMirror();
    autoSubmitAtLevel10();

    // Level-up screen flash (subtle)
    if (oldLevel < newLevel && newLevel >= 3) {
      document.body.animate(
        [{ filter: 'brightness(1)' }, { filter: 'brightness(1.35) saturate(.6)' }, { filter: 'brightness(1)' }],
        { duration: 260, easing: 'ease-out' }
      );
    }
  }

  /* ==========================================================
     BOOT
     ========================================================== */
  function init() {
    setupNav();
    setupClickCatcher();
    setupAppointmentForm();
    setupShiftToggle();
    setupReset();
    setupAudioUI();
    setupCursor();
    setupEyes();
    setupNightRounds();
    setupNurseStation();
    setupDaredevil();
    setupPrivacyLinks();
    setupMobile();
    setupFleeing();

    setupHeaderAutoHide();

    // Level effects
    C.on('corruption:level', onLevelChange);
    C.on('corruption:changed', () => {
      updateSanityMeter(C.level);
      degradeShiftLabel();
      maybeShowNightRounds();
      revealWard13();
    });

    // Click → shiver potential
    document.addEventListener('pointerdown', maybeShiver, true);

    // Corruption loop
    setInterval(corruptionTick, 900);

    // Initial level application
    applyBodyLevel(C.level);
    updateSanityMeter(C.level);
    updateFooterClock();
    degradeShiftLabel();

    // Catch any missed first interactions on next tick
    setTimeout(() => {
      applyDepartmentDropdown();
    }, 100);
  }

  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Expose minimal debug API
  window.ChaosClick = {
    reset: resetEverything,
    setLevel: (n) => { C.s.corruption = C.thresholds[n] || 0; C.updateLevel(); onLevelChange({ oldLevel: C.level, newLevel: n }); },
  };
})();
