/* =================================================================
   receptionist.js — THE RECEPTIONIST (self-aware NPC chat widget)
   -----------------------------------------------------------------
   Opens conversations ON ITS OWN based on CorruptionState.
   Analyzes:
     - click velocity (fast clicks = panic clicks)
     - hesitation time (long pauses = fear/curiosity)
     - pages visited vs pages avoided
     - hover hotspots (lingering over ward13 door, etc.)
     - daredevil button usage

   HOW TO ADD DIALOGUE LINES:
   - Add arrays in `DIALOGUE` keyed by trigger id.
   - Each line can be:
       • plain string  →  spoken as-is
       • { text: "…", delayDelete: 600, final: "…" }
         → types text, deletes after delayDelete ms, types final instead
   - Add triggers via `R.addTrigger(ruleFn)` returning a message key
     when conditions are met.
   ================================================================= */
(function () {
  'use strict';

  const C = window.CorruptionState;
  const A = window.AudioManager;
  if (!C) throw new Error('receptionist.js requires corruption.js');

  /* ---------- DIALOGUE BANK ---------- */
  const DIALOGUE = {
    // Greets after first few interactions
    greet: [
      "Oh, hello there. You're up late.",
      "Most of our visitors are asleep by now. Or unconscious. Same thing.",
      "Welcome to St. Margaret's. You're not here by accident, are you?",
    ],

    // Called when user clicks fast (velocity triggered)
    velocity: [
      "{clicks} clicks in {seconds} seconds. Are you scared, or are you curious?",
      "You're clicking very quickly. We notice when people rush.",
      "Slow down. The doctors prefer it when the patients are calm.",
      {
        text: "You seem nervous. Did you —",
        delayDelete: 1200,
        final: "You seem nervous. Did you hear something too?",
      },
    ],

    // Avoiding contact / ward13 for long
    avoidance: [
      "You haven't clicked the Contact page. That's fine. We have your information already.",
      "Still haven't visited Ward 13. Shy. Or sensible.",
      "You're avoiding the gallery. You saw something there, didn't you?",
    ],

    // When hovering a lot over a specific element
    hover_hotspot: [
      "You keep hovering over that button. Do it. Click it. I dare you.",
      "You're staring. It can tell.",
      "That element wasn't there a minute ago. Don't bother checking.",
    ],

    // Level 3-4 transitions — the uncanny valley speech
    uncanny: [
      "Something feels different, doesn't it?",
      "Don't refresh the page. It makes things worse.",
      {
        text: "By the way —",
        delayDelete: 1400,
        final: "By the way — the clock is not real. Neither is the waiting room music.",
      },
      "The departments page flickers for you too, right? …Right?",
    ],

    // User opened the form but hasn't filled it
    form_idle: [
      "You haven't finished the appointment form. Are you worried about the symptoms field?",
      "It's okay to write what you really feel. We've read stranger.",
      "You can leave the symptoms field blank. We'll fill it in for you.",
    ],

    // Ward 13 unlocked or entered
    ward13: [
      "You found it. They've been expecting you.",
      "Ward 13 is a privilege, not a right. Don't touch the IV bags.",
      "Stay on the path in Ward 13. The tiles remember weight.",
    ],

    // Night shift toggled after corruption started
    day_shift_attempt: [
      "Trying to switch back to Day Shift? Cute.",
      "Some things don't go back in the box.",
      "Day Shift is a suggestion. The night is a policy.",
    ],

    // Daredevil button pressed
    daredevil: [
      "I told you not to press that button. You pressed it anyway. Classic horror movie behavior.",
      "DO NOT PRESS buttons that say DO NOT PRESS. Where did you learn to read?",
      "You get one jumpscare per visit. Don't push your luck.",
    ],

    // High corruption (8+)
    high: [
      "It's past visiting hours. But you're not really visiting, are you?",
      "The name tags stopped matching the faces two levels ago. Did you notice?",
      "You're almost there. One more push. The doctors hate being kept waiting.",
      {
        text: "DISCHARGE STATUS:",
        delayDelete: 1800,
        final: "DISCHARGE STATUS: (pending)",
      },
    ],

    // Night rounds mini-game
    night_rounds_intro: [
      "A game appeared! It's like Candy Crush, but the candy is patients.",
      "If you win Night Rounds, we might let you keep your name.",
    ],
    night_rounds_win: [
      "Score {score}! Great job. Have a sticker. (It's not a sticker.)",
      "You won. That's worse than losing, by the way.",
      "{score} points. Your family would be proud. If they still remembered you.",
    ],

    // Response to user typing in chat
    user_chat_hello: ["Hi!", "Hello!", "Welcome back to the front desk."],
    user_chat_help: [
      "You can book an appointment above. Or below. Or wherever it appears next.",
      "Help is a strong word. We can offer you comfort. Or a sedative.",
    ],
    user_chat_afraid: [
      "Fear is a valid response to most of this building.",
      "Don't be afraid. Be very still.",
      {
        text: "There's nothing to be afra—",
        delayDelete: 1500,
        final: "There's nothing to be afraid of. *said the receptionist who is not alone at her desk.*",
      },
    ],
    user_chat_ward13: [
      "I can check if Ward 13 is accepting visitors. …No. No it is not.",
      "Ward 13 is on a floor the elevator pretends doesn't exist.",
    ],
    user_chat_default: [
      "That's an interesting thing to type at 11 PM.",
      "I'll put that in your file.",
      "Noted. Filed. Forgotten. Remembered. Fled from.",
      "Our scheduling team will reply within one business eternity.",
    ],

    // Idle chime at corruption 5+
    idle_chime: [
      "Still there?",
      "You got quiet. That usually means someone is behind you.",
      "You stopped clicking. Did you lose the mouse? Or did the mouse lose you?",
    ],
  };

  /* ---------- STATE ---------- */
  const R = {
    el: null, log: null, form: null, input: null, typing: null, closeBtn: null,
    _msgId: 0,
    _cooldownUntil: 0,
    _triggers: [],
    _lastMessageAt: 0,
    _userLastTypedForm: 0,
  };

  /* ---------- DOM ---------- */
  function bind() {
    R.el = document.getElementById('receptionist');
    R.log = document.getElementById('r-log');
    R.form = document.getElementById('r-form');
    R.input = document.getElementById('r-text');
    R.typing = document.getElementById('r-typing');
    R.closeBtn = document.getElementById('r-close');
    if (!R.el) return false;

    R.form.addEventListener('submit', e => {
      e.preventDefault();
      const text = R.input.value.trim();
      if (!text) return;
      addMessage(text, 'user');
      R.input.value = '';
      replyToUser(text);
    });
    R.closeBtn.addEventListener('click', () => close());
    return true;
  }

  /* ---------- OPEN / CLOSE ---------- */
  function open() {
    if (!R.el) return;
    R.el.classList.add('open');
    C.recordInteraction(0.3);
  }
  function close() {
    R.el && R.el.classList.remove('open');
  }

  /* ---------- TYPING EFFECT ---------- */
  function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function typeIntoMessage(msgEl, text, { speed = 16, deleteAfter = 0, replaceWith = null } = {}) {
    const display = msgEl;
    display.textContent = '';
    for (let i = 0; i < text.length; i++) {
      display.textContent += text[i];
      R.log.scrollTop = R.log.scrollHeight;
      await wait(speed + Math.random() * (speed / 2));
    }
    if (deleteAfter > 0 && replaceWith) {
      await wait(deleteAfter);
      // Delete one char at a time
      while (display.textContent.length > 0) {
        display.textContent = display.textContent.slice(0, -1);
        await wait(18);
      }
      for (let i = 0; i < replaceWith.length; i++) {
        display.textContent += replaceWith[i];
        await wait(speed + Math.random() * (speed / 2));
      }
    }
  }

  function showTyping(visible) {
    if (!R.typing) return;
    R.typing.hidden = !visible;
    R.log.scrollTop = R.log.scrollHeight;
  }

  function addMessage(raw, from = 'bot', opts = {}) {
    const el = document.createElement('div');
    el.className = 'r-msg r-msg--' + from;
    el.dataset.id = ++R._msgId;
    R.log.appendChild(el);
    if (A && A.stingReceptionist) A.stingReceptionist();
    (async () => {
      if (from === 'bot') {
        showTyping(true);
        await wait(400 + Math.random() * 400);
        showTyping(false);
      }
      if (typeof raw === 'string') {
        if (from === 'bot') await typeIntoMessage(el, fillPlaceholders(raw), opts);
        else el.textContent = raw;
      } else if (raw && raw.text) {
        const filledText = fillPlaceholders(raw.text);
        const filledFinal = raw.final ? fillPlaceholders(raw.final) : null;
        await typeIntoMessage(el, filledText, {
          speed: opts.speed,
          deleteAfter: raw.delayDelete || 0,
          replaceWith: filledFinal || null,
        });
      }
      R.log.scrollTop = R.log.scrollHeight;
      R._lastMessageAt = Date.now();
    })();
    return el;
  }

  function fillPlaceholders(str) {
    const s = C.s;
    const clicks = s.totalClicks;
    const seconds = Math.max(1, Math.round(C.getTimeOnSite()));
    const speed = C.getAvgClickSpeed();
    return str
      .replace(/\{clicks\}/g, clicks)
      .replace(/\{seconds\}/g, seconds)
      .replace(/\{score\}/g, s._lastGameScore || 'some')
      .replace(/\{speed\}/g, speed === Infinity ? 'slow' : Math.round(speed) + 'ms');
  }

  /* ---------- TRIGGER SYSTEM ----------
     Each trigger: async fn(state) → returns { key, from?, opts? } or null.
     Triggers are called with ~1s interval and must respect cooldown. */
  function addTrigger(fn) { R._triggers.push(fn); }
  R._triggers = []; R.addTrigger = addTrigger; R._raw = R;

  function randomOf(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

  async function runTriggers() {
    if (!R.el) return;
    const now = Date.now();
    if (now < R._cooldownUntil) return;
    for (const fn of R._triggers) {
      try {
        const result = await fn(C.s, R);
        if (!result) continue;
        const { key, from = 'bot', opts = {}, cooldown = 18000 } = result;
        const lines = DIALOGUE[key];
        if (!lines || !lines.length) continue;
        if (!R.el.classList.contains('open')) open();
        R._cooldownUntil = now + cooldown;
        addMessage(randomOf(lines), from, opts);
        return; // one trigger per tick
      } catch (e) {
        console.error('[receptionist] trigger error', e);
      }
    }
  }

  /* ---------- BUILT-IN TRIGGERS ---------- */
  function registerDefaultTriggers() {
    // 1. First few clicks: greeting
    R.addTrigger(s => {
      if (s.flags.receptionistGreeted) return null;
      if (s.totalClicks >= 2 && s.totalClicks <= 4) {
        s.flags.receptionistGreeted = true;
        return { key: 'greet', cooldown: 20000 };
      }
      return null;
    });

    // 2. Velocity: many fast clicks
    R.addTrigger(s => {
      if (s.flags.receptionistVelocityComment) return null;
      const recent = s.recentClicks.length;
      if (recent >= 7 && C.getTimeOnSite() < 30) {
        s.flags.receptionistVelocityComment = true;
        return { key: 'velocity', cooldown: 25000 };
      }
      return null;
    });

    // 3. Level 3 → uncanny dialogue
    R.addTrigger(s => {
      if (!s._saidUncanny && s.level >= 3 && s.level <= 4) {
        s._saidUncanny = true;
        return { key: 'uncanny', cooldown: 22000 };
      }
      return null;
    });

    // 4. Avoidance
    R.addTrigger(s => {
      const t = C.getTimeOnSite();
      if (t > 45 && s.pagesAvoided.size >= 1 && !s._saidAvoidance) {
        s._saidAvoidance = true;
        return { key: 'avoidance', cooldown: 30000 };
      }
      return null;
    });

    // 5. Hover hotspots (gallery / ward13 door)
    C.on('cor:hover-hotspot', ({ id, count }) => {
      if (count === 10 && !C.s._saidHoverHotspot) {
        C.s._saidHoverHotspot = true;
        if (!R.el.classList.contains('open')) open();
        addMessage(randomOf(DIALOGUE.hover_hotspot));
        R._cooldownUntil = Date.now() + 25000;
      }
    });

    // 6. High corruption 8+
    R.addTrigger(s => {
      if (s.level >= 8 && !s._saidHigh) {
        s._saidHigh = true;
        return { key: 'high', cooldown: 28000 };
      }
      return null;
    });

    // 7. Idle (no clicks for long)
    C.on('corruption:idle-start', () => {
      if (C.level >= 5 && !C.s._saidIdle) {
        C.s._saidIdle = true;
        setTimeout(() => {
          if (!R.el.classList.contains('open')) open();
          addMessage(randomOf(DIALOGUE.idle_chime));
        }, 3000);
      }
    });

    // 8. Appointment form filled partially
    R.addTrigger(s => {
      const f = document.getElementById('f-name');
      if (f && f.value && s.totalClicks > 20 && !s._saidFormIdle) {
        const appoint = document.getElementById('appointment');
        if (appoint && appoint.classList.contains('active')) {
          s._saidFormIdle = true;
          return { key: 'form_idle', cooldown: 35000 };
        }
      }
      return null;
    });

    // 9. Day shift toggle after corruption 3+
    document.addEventListener('change', (e) => {
      if (e.target && e.target.id === 'shift-checkbox') {
        const night = e.target.checked;
        if (!night && C.level >= 3 && !C.s._saidDayShift) {
          C.s._saidDayShift = true;
          setTimeout(() => {
            if (!R.el.classList.contains('open')) open();
            addMessage(randomOf(DIALOGUE.day_shift_attempt));
          }, 600);
        }
      }
    });
  }

  /* ---------- USER CHAT INTENT PARSER ---------- */
  function replyToUser(text) {
    const t = text.toLowerCase();
    let key = 'user_chat_default';
    if (/\b(hi|hello|hey|yo|sup|greetings)\b/.test(t)) key = 'user_chat_hello';
    else if (/\b(help|support|assist|stuck)\b/.test(t)) key = 'user_chat_help';
    else if (/\b(scared|afraid|fear|terrify|horror|creep)\b/.test(t)) key = 'user_chat_afraid';
    else if (/(ward ?13|ward13|thirteen|13)/.test(t)) key = 'user_chat_ward13';

    C.recordInteraction(0.4);
    setTimeout(() => addMessage(randomOf(DIALOGUE[key])), 500);
  }

  /* ---------- PUBLIC API ---------- */
  function say(keyOrText, opts = {}) {
    if (!R.el) return;
    if (!R.el.classList.contains('open')) open();
    if (DIALOGUE[keyOrText]) {
      return addMessage(randomOf(DIALOGUE[keyOrText]), 'bot', opts);
    }
    return addMessage(keyOrText, 'bot', opts);
  }

  function init() {
    if (!bind()) return;
    registerDefaultTriggers();
    // Poll triggers every ~1.5 seconds
    setInterval(runTriggers, 1500);

    // Wire events fired from main.js that Receptionist cares about.
    C.on('receptionist:say', (key) => say(key));
  }

  window.Receptionist = {
    init, say, open, close, addTrigger: R.addTrigger,
    DIALOGUE, // exposed so main.js / judges can read back
  };

  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
